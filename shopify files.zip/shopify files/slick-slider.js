<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.css"/>

<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick-theme.min.css"/>
  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.min.js"></script>
				
				<div id="hero">
<div id="banner-slider">
{% for block in section.blocks  %}
        
<div>
      <img src="{{ block.settings.imagePic | img_url: 'master' }}" data-srcset="http://placehold.it/650x300?text=1-650w 650w, http://placehold.it/960x300?text=1-960w 960w" data-sizes="100vw">
    </div>

        {% endfor %}
 
  </div>
</div>
<!--  {% for block in section.blocks  %}
<div>
      <img src="{{ block.settings.imagePic | img_url: 'master' }}">

        {% endfor %} -->



{% schema %}
  {
    "name": "Slide Show",
    "settings": [
	
		],
		"blocks": [
    {
      "type": "products",
      "name": "Section2",
      "settings": [
        {
          "type": "image_picker",
          "id": "imagePic",
          "label": "Image"
        }
      ]
    }
  ]
		}
		{% endschema %}

  
    <script>
    
    $(document).ready(function(){
  $('#banner-slider').slick({
  slidesToShow: 1,
  slidesToScroll: 1,
    dots: true,
  infinite: true,
  speed: 500,
  fade: true
});
});
    <script>