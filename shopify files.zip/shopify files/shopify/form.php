<!DOCTYPE html>
<html>
<head>
<title>Page Title</title>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
<link rel="stylesheet" type="text/css" href="/shopify/css/fortvision.css">
<!-- Font css -->
<link href="https://fonts.googleapis.com/css?family=Roboto&display=swap" rel="stylesheet">

<style type="text/css">
body
{
	font-family: 'Roboto', sans-serif;
}
*{-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;}
.fortvision-form-control p.submit {    
	float: none;
    width: 170px;
    margin: 0 auto;
}
p.fortvision-support {
    width: 100%;
    margin-bottom: 20px;
}
</style>
</head>
<body>

<?php 
ini_set('display_errors', 1);
ini_set('error_reporting', E_ALL);
       require 'vendor/autoload.php';
	
	use Carbon\Carbon;
	use GuzzleHttp\Client;
	
	$dotenv = new Dotenv\Dotenv(__DIR__);
	$dotenv->load();
	$client = new Client();
	$store =$_GET['shop'];
	//$nonce =$_GET['nonce'];
	$theme_id = "";
	$access_token="";
	
	$db = new Mysqli(getenv('MYSQL_HOST'), getenv('MYSQL_USER'), getenv('MYSQL_PASS'), getenv('MYSQL_DB')); 
	
	$publisher_id = '' ;
	
	        
	     if (!empty($_POST)) 
	     {
	       
			       $publisher_id= $_POST['publisher_id'];
			  
			     
			        if ($select = $db->prepare("SELECT publisher_id FROM store_data WHERE store = ?")) {
			
					        $select->bind_param('s', $store);
					        $select->execute();
					        $select->bind_result($publisherid);
					        $select->fetch();
					        $select->close();
			        
					        if($publisherid != '')
					        {
					           $db->query("UPDATE store_data SET publisher_id = '$publisher_id' WHERE store = '$store'");
					        
					        }
					        else
					        {
					          if ($query = $db->prepare('INSERT INTO store_data SET store = ?, publisher_id = ?')) {
						        
						        		$query->bind_param('ss', $store, $publisher_id);
						        		$query->execute();
						        		$query->close();
						        		
						        	}
					        
					        
					        }
			        
			        }
			        
			        /* get access token in app database */
			        
		     if ($select = $db->prepare("SELECT access_token FROM installs WHERE store = ? ")) {
	
			        $select->bind_param('s', $store);
			        $select->execute();
			        $select->bind_result($access_token);
			        $select->fetch();
			        $select->close();
					
			/* 	echo "sdfdfsd";
				echo $access_token;
				
				die;  */
				        
				        if ($access_token !='') {
							
							
				/* 								$script_tag_ajax_cdn = [
																		'script_tag' => [
																		   'src' => 'https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js', 
																		   'event' => 'onload'      
																		   ] ];
																$response_script_cdn = $client->request('POST', 'https://'.$store.'/admin/script_tags.json', [
																	'json'    => $script_tag_ajax_cdn,
																	'headers' => ['X-Shopify-Access-Token' => $access_token]
																]);
																
																
																			$script_tag_ajax = [
																		'script_tag' => [
																		   'src' => 'https://fortvision.com/shopify/trail.js',
																		   'id' => 'idTrial',
																		   'event' => 'onload'      
																		   ] ];
																$response_script = $client->request('POST', 'https://'.$store.'/admin/script_tags.json', [
																	'json'    => $script_tag_ajax,
																	'headers' => ['X-Shopify-Access-Token' => $access_token]
																]);
																	$result_script = json_decode($response_script->getBody()->getContents(), true);
																	 */
																	
																	
												$response_webhook  = $client->request(
												'GET', 
												"https://{$store}/admin/script_tags.json",
												[   
													'query' => [
														'fields' => 'id,src',
														'access_token' => $access_token
													]
												]
											);

											$get_res_webhook  = json_decode($response_webhook ->getBody()->getContents(), true);
											
										
															
											$res_title_webhook = array();
											foreach($get_res_webhook['script_tags'] as $r){
												$script_id = $r['id'];
												$res_title_webhook[$script_id] = $r['src'];
											}

											$res_title_webhook = array();
											foreach($get_res_webhook['script_tags'] as $r){
												$res_title_webhook[] = $r['src'];
											} 
											
														
										if (in_array("https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js", $res_title_webhook)){}
													
													else{		
													$script_tag_ajax_cdn = [
																		'script_tag' => [
																		   'src' => 'https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js', 
																		   'event' => 'onload'      
																		   ] ];
																$response_script_cdn = $client->request('POST', 'https://'.$store.'/admin/script_tags.json', [
																	'json'    => $script_tag_ajax_cdn,
																	'headers' => ['X-Shopify-Access-Token' => $access_token]
																]);
													
													} 
													
												if (in_array("https://fortvision.com/shopify/trail.js", $res_title_webhook)){}
													
													else{		
														$script_tag_ajax = [
																		'script_tag' => [
																		   'src' => 'https://fortvision.com/shopify/trail.js', 
																		   'event' => 'onload'      
																		   ] ];
																$response_script = $client->request('POST', 'https://'.$store.'/admin/script_tags.json', [
																	'json'    => $script_tag_ajax,
																	'headers' => ['X-Shopify-Access-Token' => $access_token]
																]);
																	$result_script = json_decode($response_script->getBody()->getContents(), true);
													
													} 
																	
				        
						}
				      }
	   	 }
	   	 
	   	 



			

	
	
	       
	      
	      
            if ($select = $db->prepare("SELECT publisher_id FROM store_data WHERE store = ?")) {
	
	        $select->bind_param('s', $store);
	        $select->execute();
	        $select->bind_result($publisher_id);
	        $select->fetch();
	        $select->close();
	        
	        }
            
	 

?>

<div class="wrap">
        <div class="fortvision-admin">
        	<div class="fortvision-admin-inner">
        		<div class="fortvision-header">
        			<div class="fortvision-header-inner">
        				<div class="fortvision-logo"><a href="https://my.fortvision.com/"><img src="/shopify/images/logo-white.png" alt="FORTVISION"></a></div>
        				<div class="fortvision-header-text">Settings</div>
        			</div>
        		</div>
        		<div class="fortvision-publisher-form">
                                        <div style="display:none;" class="pubid_activate_msg">
                                        <span  class="dashicons dashicons-yes"></span> Publisher ID Activated</div>
                            	 <form action="" method="post">
			            <input type="hidden" name="option_page" value="fortvision-plugin-settings">
			            
			            <?php if($publisher_id !='') { ?>
			            
			            <input type="hidden" name="action" value="update">
			            <?php } ?>
			           <div class="fortvision_content">
					      
                            <p> <b><?php if($publisher_id !='') { ?>Thanks! <?php } ?></b>  Now, head over to <a target="_blank" href="https://my.fortvision.com/">https://my.fortvision.com/</a> and begin benefitting from personalized, interactive content experiences.</p>
                        </div>
			            <div class="fortvision-form-control">
			            	<label for="publisher_id">Publisher ID:</label>
			            	<input type="text" placeholder="12XX38" name="publisher_id" value="<?php if( isset($publisher_id)){ echo $publisher_id; } ?>" size="50">
			            </div>
			            <div class="fortvision-form-control fortvision-form-control-submit">
			            	<p class="fortvision-support">
							Need help with your first campaign? <br> Contact us at <a target="_blank" href="mailto:support@fortvision.com">support@fortvision.com</a>, and someone will get back to you within 24 hours!<br>
							FORTVISION<br><a target="_blank" href="https://my.fortvision.com">https://my.fortvision.com</a></p>
                            <p class="submit"><input type="submit" name="submit" id="submit" class="button button-primary" value="Save Changes"></p>			            </div>
			        </form>
        		</div>
        	</div>
        </div>
    </div>

</body>
</html>



