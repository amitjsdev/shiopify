<?php

 header('Access-Control-Allow-Origin: *'); 


//ini_set('error_reporting', E_ALL);
       require 'vendor/autoload.php';
	
	use Carbon\Carbon;
	use GuzzleHttp\Client;
	
	$dotenv = new Dotenv\Dotenv(__DIR__);
	$dotenv->load();
	$client = new Client();

	

	 
  	$store_name = $_POST["store_name"];

	$popupHeading = $_POST["popupHeading"];
	$popupContent = $_POST["popupContent"];
	$disclaimerText = $_POST["disclaimerText"];
	$nothanks = $_POST["nothanks"];
	
					$results = $db->query("SELECT * FROM popup_detail where store_name = '$store_name'");	
					if($results->num_rows == 0){
					 echo 	 $ans="insert into popup_detail(popupHeading,popupContent,disclaimerText,nothanks,store_name)values('$popupHeading','$popupContent','$disclaimerText','$nothanks','$store_name')";
						$reslt = mysqli_query($db,$ans);	
						if($reslt){
							echo "Updated";
						}else{
							echo "Not Updated";
						}
						
					}else{
						$update_sql="UPDATE `popup_detail` set popupHeading='$popupHeading', popupContent ='$popupContent', disclaimerText='$disclaimerText', disclaimerText='$disclaimerText' , nothanks='$nothanks'  where  store_name='$store_name'";
					
						$reslt=mysqli_query($db,$update_sql);	
						if($reslt){
							echo "Updated";
						}else{
							echo "Not Updated";
						}
					}
					echo "sdfd";
	 die;
					echo "Not Updated";
			
 
 
			