<?php 
//ini_set('display_errors', 1);

ini_set('error_reporting', E_ALL);
       require 'vendor/autoload.php';
	
	use Carbon\Carbon;
	use GuzzleHttp\Client;
	
	$dotenv = new Dotenv\Dotenv(__DIR__);
	$dotenv->load();
	$client = new Client();
	 $store =$_GET['shop'];
	//die;
	// $store ="suffes-dev.myshopify.com";
	
	//$nonce =$_GET['nonce'];
	$theme_id = "";
	$access_token="";
	
	$db = new Mysqli(getenv('MYSQL_HOST'), getenv('MYSQL_USER'), getenv('MYSQL_PASS'), getenv('MYSQL_DB')); 
	
			        /* get access token in app database */
					$select = $db->prepare("SELECT access_token FROM installs WHERE store = ? ");
			        $select->bind_param('s', $store);
			        $select->execute();
			        $select->bind_result($access_token);
			        $select->fetch();
			        $select->close();
					//echo $access_token."dfdffdf<br>";
		if ($access_token !='') {
			//echo $access_token;
									/* orders */
					/* orders */
	$response_orders = $client->request(
		'GET', 
		"https://{$store}/admin/orders.json",
		[
			'query' => [
				'fields' => 'id,created_at,line_items,customer,name',
				'access_token' => $access_token,
				'limit' =>200
			]
		]	
		);
		$count=1;
		$result_orders = json_decode($response_orders->getBody()->getContents(), true);

 	/*   echo "<pre>";
		print_r($result_orders);  
		 echo "</pre>"; */
		//die;     

			if($result_orders !=""){
				foreach ($result_orders['orders'] as $key=>$value){
					$product_id=$value['line_items'][0]['product_id'];
					 $mealsCountarr=$value['line_items'][0]['properties'];
					 foreach($mealsCountarr as $propertiesVal){
						 if($propertiesVal["name"] == "Meals_Count"){
						  $mealsCount = $propertiesVal["value"];
						 }
					 } 
					$customer_id=$value['customer']['id'];
					$email=$value['customer']['email'];
					 $shop_id=$value['name'];
					 $created_at=$value['created_at'];
					 $created_at = substr($created_at, 0, strpos($created_at, "T"));
					//echo str_replace("world","Peter","Hello world!");
					foreach($value['line_items'] as $key=>$secondVal){
						$order_id=$secondVal['id'];
					
						
						$sql ="SELECT * FROM new_invoice where email='".$email."'";
						$result_num = $db->query($sql);
						$num_rows=$result_num->num_rows; 
						if($num_rows == ""){
							 $insert_product="INSERT INTO new_invoice(customer_id,mealsCount,shop_id,email,status) VALUES ('$customer_id','$mealsCount','$shop_id','$email','')";	
							if($db->query($insert_product) === TRUE){
								//echo "Insert sucess fully";
							}
									
						}else{
							if($mealsCount != ""){
								$arrr = array();
									$sqlcount ="SELECT * FROM new_invoice where email='".$email."'";
									$result_num_count = $db->query($sqlcount);
									//$row=mysqli_fetch_assoc($result_num_count);
						
									foreach($result_num_count as $rowVal){
										$arrr[] = $rowVal["shop_id"];
									}
									$arrr2 = $arrr;
									/*  echo "<pre>";
										print_r($arrr);  
										echo "</pre>";  */
								if(in_array($shop_id,$arrr)){
									
									
								}else{
									 $insert_product="INSERT INTO new_invoice(customer_id,mealsCount,shop_id,email,status) VALUES ('$customer_id','$mealsCount','$shop_id','$email','')";	
									if($db->query($insert_product) === TRUE){
										echo "Insert sucess fully";
									}
								
									/* if($row['mealsCount'] != ""){
										$mealVal = $row['mealsCount'];
										echo $totalMeal = $mealVal + $mealsCount;
									}else{
										
										echo $totalMeal = $mealsCount;
									} */
									//$update_sql="UPDATE `new_invoice` set mealsCount='$totalMeal' where email='$email'";
									//$reslt=mysqli_query($db,$update_sql);	
								
								} 
							}
						}
					}			
				}
			}
		}
			/* orders end */

	?>
	<!DOCTYPE html>
	<html>
	<head>
		<link rel="stylesheet" href="/shopify-app/css/app-style.css?<?php echo rand(2,1000);?>">
		<link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
		<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" href="../assets/css/styles.css">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		<link rel="stylesheet" type="text/css" href="../assets/css/demo.css">
	</head>
	<body>

<div class="tabsList">
<ul class="ulList">
	<li class="tabLi firtsTabLi"><a href="/shopify-app/products.php?shop=<?php echo $store;?>" class="orderPage">Product List</a></li>

</ul>
</div>
	<div id="plisting" class="tabcontent active">
	<h1 class="listHeading"> List Of All Orders</h1>
		<table style="display:;" class="table_main" border="1">
			<thead>
				<tr class="trtop_gapiheading main_porduct_table">
					<th class="firstTh">Sr No.</th>
					<!--<th class="secondTh">product_id</th>-->
					<th class="secondTh">Order ID</th>
					<th class="thirdTh">customer_id</th>
					<th class="thirdTh">Meal Count</th>
					<th class="thirdTh">Email Id</th>
					<th class="thirdTh">status</th>
					<th class="thirdTh">Action</th>
				
				</tr>
			</thead>
			 <tbody> 
				<?php
			/* 	$sql ="SELECT * FROM new_invoice";
				$result_num = $db->query($sql);
				$num_rows=$result_num->num_rows; 
				$row=mysqli_fetch_assoc($result_num); */
			 $sqlval ="select email,sum(mealsCount) from new_invoice group by email";
						/* select email, sum(mealsCount) from table group by email
						array */
				$result_num_sqlval = $db->query($sqlval);
			//	if($num_rows !=""){ 
					$i=1;
					foreach($result_num_sqlval as $val_result){
						$sql ="SELECT * FROM new_invoice where email = '".$val_result['email']."'";
						$result_num = $db->query($sql);
						$num_rows=$result_num->num_rows; 
						$row=mysqli_fetch_assoc($result_num);		
									 
						?>
							<tr class='trtop_gapi '> 
								<td><?php echo $i;?></td>
								<td class='tdtop_gapi'><?php echo $row['shop_id'];  ?></td>
								<td class='tdtop_gapi'><?php echo $row['customer_id'];  ?></td>
								<td class='tdtop_gapi'><?php echo $val_result['sum(mealsCount)']; ?></td>
								<td class='tdtop_gapi'><?php echo $val_result['email']; ?></td>
								<td class='tdtop_gapi'><?php echo $val_result['status']; ?></td>
								<td><a href="send_invoice.php?shop_id=<?php echo $val_result['shop_id'];?>&shop=<?php echo $store;?>&email=<?php echo $email;?>">Send</a></td>
							</tr>	
						<?php
						$i++;
					}
				// }
				?>
			</tbody>
		</table>
	</div>
</body>
</html>