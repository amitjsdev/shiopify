<?php

 header('Access-Control-Allow-Origin: *'); 

		ini_set('error_reporting', E_ALL);
		require 'vendor/autoload.php';
		use Carbon\Carbon;
		use GuzzleHttp\Client;
		$dotenv = new Dotenv\Dotenv(__DIR__);
		$dotenv->load();
		$client = new Client();
		$db = new Mysqli(getenv('MYSQL_HOST'), getenv('MYSQL_USER'), getenv('MYSQL_PASS'), getenv('MYSQL_DB'));
		  $cartpopup = $_GET['cartpopup'];

	 
	  $store = $_GET['shop'];
//$store = "suffes-dev.myshopify.com";
  $product_id = $_GET['product_id'];
//$product_id = "4430288945203";



			$arr = array();
			$results = $db->query("SELECT * FROM product_detail where storeName ='$store' AND product_id = '$product_id'");	
				 $row = mysqli_fetch_assoc($results); 
				 
				 
				 $arr["product_description"]=$row["product_description"];
				 $arr["meals_count"]=$row["meals_count"];
				 
			echo json_encode($arr);
 
			