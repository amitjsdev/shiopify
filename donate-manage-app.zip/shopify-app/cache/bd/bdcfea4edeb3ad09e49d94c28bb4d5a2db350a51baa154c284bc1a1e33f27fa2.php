<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* install.html */
class __TwigTemplate_2d3d886deb8ac2b4eba89eaa0de0e081c9dc698108ef79e69a09d48caeacc396 extends \Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\">
<head>
\t<meta charset=\"UTF-8\">
\t<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
\t<title>Install</title>

<!-- Font css -->
<link href=\"https://fonts.googleapis.com/css?family=Roboto&display=swap\" rel=\"stylesheet\">

<!-- Custom CSS  -->
<style type=\"text/css\">
*{-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;}\t
html{height: 100%;}
body {font-family: 'Roboto', sans-serif;padding: 0;margin: 0;background: #fdfdff;height: 100%;width: 100%;display: -webkit-box!important;display: -ms-flexbox!important;display: flex!important;-webkit-box-align: center!important;-ms-flex-align: center!important;align-items: center!important;-webkit-box-pack: center!important;-ms-flex-pack: center!important;justify-content: center!important;}\t
a{text-decoration: none;}
.middle_part {
    max-width: 650px;
    width: 90%;
    text-align: center;
    background-color: #fff;
    -webkit-box-shadow: 0 4px 30px 0 rgba(0,0,0,.2);
    box-shadow: 0 4px 30px 0 rgba(0,0,0,.2);
    border: 1px solid #eaeaea;
    position: relative;

}
nav.top_part {
    float: left;
    width: 100%;
    border-bottom: 2px solid #e1e1e1;
}
nav.top_part a {
    color: #2c454a;
    font-weight: normal;
}
nav.top_part h2 {
    font-size: 20px;
    font-weight: lighter;
}

.middle_part form fieldset {border: none;}
.middle_part form fieldset input[type=\"text\"] {
    height: 50px;
    max-width: 100%;
    width: 100%;
    padding: 0;
    border-radius: 0;
    margin-left: 0;
    border: none;
    border-bottom: 2px solid #2c454a;
}
.middle_part main {
    padding: 90px 60px;
    float: left;
    width: 100%;
}
.middle_part form button {
    height: 50px;
    width: 130px;
    background: #5b94ff;
    border: none;
    color: #fff;
    font-size: 15px;
    font-family: 'Roboto', sans-serif;
    cursor: pointer;
    border-radius: 60px;
    margin-top: 30px;
    text-transform: uppercase;
}
.middle_part form button:hover {background: #3b74e0;}
.middle_part form {position: relative;}
.middle_part form fieldset input[type=\"text\"]:focus{box-shadow: none;outline: none;}
span.store__Name {
    float: left;
    width: 100%;
    text-align: left;
}
.position {
    position: absolute;
}
.position img
{
\twidth: 250px;
}
.top_left_graphic {
    left: 0;
    top: 0;
}
.bottom_right_graphic {
    right: 0;
    bottom:0px;
}
.bottom_right_graphic img {
    position: absolute;
    bottom: 0;
    right: 0;
    width: 270px;
}

@media (max-width: 992px)
{

\t.middle_part main {
\t    padding: 40px 10px;
\t    float: left;
\t    width: 100%;
\t}
\tnav.top_part h2 {
\t    font-size: 16px;
\t    font-weight: lighter;
\t    padding: 0 30px;
\t}
}
@media (max-width: 600px)
{
\t.middle_part form button{position: relative;}
\t.middle_part form fieldset input[type=\"text\"]{margin-top: 10px;}
\t.middle_part h2{padding-left: 0}
\t.position img {
    width: 40%;
}
.bottom_right_graphic {
    width: 100%;
}
}

}

@media (max-width: 475px)
{
.position img {
    width: 20%;
}\t
}
</style>

<body style=\"position: relative;\">
\t
<div class=\"top_left_graphic position\">
\t<img src=\"fort-waves-colors-top-left.png\" alt=\"\">
</div>
<div class=\"bottom_right_graphic position\">
\t<img src=\"fort-waves-colors-bottom-right.png\" alt=\"\">
</div>

\t<div class=\"middle_part\">
\t\t\t<nav class=\"top_part\">
\t\t\t  <a href=\"#\" class=\"brand\">
\t\t\t    <h2>Install Gift Handwritten App On Your Shopify App</h2>
\t\t\t  </a>
\t\t\t</nav>
\t
\t\t\t<main>
\t\t\t\t<form id=\"appForm\" method=\"POST\" action=\"/shopify-app/install.php\">
\t\t\t\t\t<fieldset class=\"flex one\">
\t\t\t\t\t  <label><span class=\"store__Name\">Store Name</span>
\t\t\t\t\t  \t<input type=\"text\" name=\"store\" class=\"storeName\"  placeholder=\"e.g.store.myshopify.com\">
\t\t\t\t\t  </label>
\t\t\t\t\t</fieldset>
\t\t\t\t\t<button type=\"submit\">Install</button>
\t\t\t\t</form>
\t\t\t</main>
   </div>
   <script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js\"></script>
\t<script>
\t
\tjQuery(document).ready(function(){

\tjQuery(document).on('submit','#appForm',function(){
\t\t\t\tvar storeName = jQuery('.storeName').val();


\t\t\t\tif(storeName.indexOf('https') != -1){
\t\t\t\t
\t\t\t\talert(\"Please remove https:// from store url\");
\t\t\t\t\treturn false;
\t\t\t\t}
\t\t\t\t
\t\t\t\t\tif(storeName.indexOf('http') != -1){
\t\t\t\t\t\talert(\"Please remove http:// from store url\");
\t\t\t\t\treturn false;
\t\t\t\t
\t\t\t\t}


\t\t});
    });

\t</script>
</body>
</html>";
    }

    public function getTemplateName()
    {
        return "install.html";
    }

    public function getDebugInfo()
    {
        return array (  30 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("<!DOCTYPE html>
<html lang=\"en\">
<head>
\t<meta charset=\"UTF-8\">
\t<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
\t<title>Install</title>

<!-- Font css -->
<link href=\"https://fonts.googleapis.com/css?family=Roboto&display=swap\" rel=\"stylesheet\">

<!-- Custom CSS  -->
<style type=\"text/css\">
*{-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;}\t
html{height: 100%;}
body {font-family: 'Roboto', sans-serif;padding: 0;margin: 0;background: #fdfdff;height: 100%;width: 100%;display: -webkit-box!important;display: -ms-flexbox!important;display: flex!important;-webkit-box-align: center!important;-ms-flex-align: center!important;align-items: center!important;-webkit-box-pack: center!important;-ms-flex-pack: center!important;justify-content: center!important;}\t
a{text-decoration: none;}
.middle_part {
    max-width: 650px;
    width: 90%;
    text-align: center;
    background-color: #fff;
    -webkit-box-shadow: 0 4px 30px 0 rgba(0,0,0,.2);
    box-shadow: 0 4px 30px 0 rgba(0,0,0,.2);
    border: 1px solid #eaeaea;
    position: relative;

}
nav.top_part {
    float: left;
    width: 100%;
    border-bottom: 2px solid #e1e1e1;
}
nav.top_part a {
    color: #2c454a;
    font-weight: normal;
}
nav.top_part h2 {
    font-size: 20px;
    font-weight: lighter;
}

.middle_part form fieldset {border: none;}
.middle_part form fieldset input[type=\"text\"] {
    height: 50px;
    max-width: 100%;
    width: 100%;
    padding: 0;
    border-radius: 0;
    margin-left: 0;
    border: none;
    border-bottom: 2px solid #2c454a;
}
.middle_part main {
    padding: 90px 60px;
    float: left;
    width: 100%;
}
.middle_part form button {
    height: 50px;
    width: 130px;
    background: #5b94ff;
    border: none;
    color: #fff;
    font-size: 15px;
    font-family: 'Roboto', sans-serif;
    cursor: pointer;
    border-radius: 60px;
    margin-top: 30px;
    text-transform: uppercase;
}
.middle_part form button:hover {background: #3b74e0;}
.middle_part form {position: relative;}
.middle_part form fieldset input[type=\"text\"]:focus{box-shadow: none;outline: none;}
span.store__Name {
    float: left;
    width: 100%;
    text-align: left;
}
.position {
    position: absolute;
}
.position img
{
\twidth: 250px;
}
.top_left_graphic {
    left: 0;
    top: 0;
}
.bottom_right_graphic {
    right: 0;
    bottom:0px;
}
.bottom_right_graphic img {
    position: absolute;
    bottom: 0;
    right: 0;
    width: 270px;
}

@media (max-width: 992px)
{

\t.middle_part main {
\t    padding: 40px 10px;
\t    float: left;
\t    width: 100%;
\t}
\tnav.top_part h2 {
\t    font-size: 16px;
\t    font-weight: lighter;
\t    padding: 0 30px;
\t}
}
@media (max-width: 600px)
{
\t.middle_part form button{position: relative;}
\t.middle_part form fieldset input[type=\"text\"]{margin-top: 10px;}
\t.middle_part h2{padding-left: 0}
\t.position img {
    width: 40%;
}
.bottom_right_graphic {
    width: 100%;
}
}

}

@media (max-width: 475px)
{
.position img {
    width: 20%;
}\t
}
</style>

<body style=\"position: relative;\">
\t
<div class=\"top_left_graphic position\">
\t<img src=\"fort-waves-colors-top-left.png\" alt=\"\">
</div>
<div class=\"bottom_right_graphic position\">
\t<img src=\"fort-waves-colors-bottom-right.png\" alt=\"\">
</div>

\t<div class=\"middle_part\">
\t\t\t<nav class=\"top_part\">
\t\t\t  <a href=\"#\" class=\"brand\">
\t\t\t    <h2>Install Gift Handwritten App On Your Shopify App</h2>
\t\t\t  </a>
\t\t\t</nav>
\t
\t\t\t<main>
\t\t\t\t<form id=\"appForm\" method=\"POST\" action=\"/shopify-app/install.php\">
\t\t\t\t\t<fieldset class=\"flex one\">
\t\t\t\t\t  <label><span class=\"store__Name\">Store Name</span>
\t\t\t\t\t  \t<input type=\"text\" name=\"store\" class=\"storeName\"  placeholder=\"e.g.store.myshopify.com\">
\t\t\t\t\t  </label>
\t\t\t\t\t</fieldset>
\t\t\t\t\t<button type=\"submit\">Install</button>
\t\t\t\t</form>
\t\t\t</main>
   </div>
   <script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js\"></script>
\t<script>
\t
\tjQuery(document).ready(function(){

\tjQuery(document).on('submit','#appForm',function(){
\t\t\t\tvar storeName = jQuery('.storeName').val();


\t\t\t\tif(storeName.indexOf('https') != -1){
\t\t\t\t
\t\t\t\talert(\"Please remove https:// from store url\");
\t\t\t\t\treturn false;
\t\t\t\t}
\t\t\t\t
\t\t\t\t\tif(storeName.indexOf('http') != -1){
\t\t\t\t\t\talert(\"Please remove http:// from store url\");
\t\t\t\t\treturn false;
\t\t\t\t
\t\t\t\t}


\t\t});
    });

\t</script>
</body>
</html>", "install.html", "/home/odin/public_html/shopify-app/templates/install.html");
    }
}
