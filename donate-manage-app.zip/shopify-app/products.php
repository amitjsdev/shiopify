<?php 
//ini_set('display_errors', 1);



ini_set('error_reporting', E_ALL);
       require 'vendor/autoload.php';
	
	use Carbon\Carbon;
	use GuzzleHttp\Client;
	include_once "pagination.php";
	$dotenv = new Dotenv\Dotenv(__DIR__);
	$dotenv->load();
	$client = new Client();
	 $store =$_GET['shop'];
	//die;
	// $store ="suffes-dev.myshopify.com";
	
	//$nonce =$_GET['nonce'];
	$theme_id = "";
	$access_token="";
	
	$db = new Mysqli(getenv('MYSQL_HOST'), getenv('MYSQL_USER'), getenv('MYSQL_PASS'), getenv('MYSQL_DB')); 
	
	
			        /* get access token in app database */
					$select = $db->prepare("SELECT access_token FROM installs WHERE store = ? ");
			        $select->bind_param('s', $store);
			        $select->execute();
			        $select->bind_result($access_token);
			        $select->fetch();
			        $select->close();


	?>
	
	<!DOCTYPE html>
	<html>
	<head>
		<link rel="stylesheet" href="/shopify-app/css/app-style.css?<?php echo rand(2,1000);?>">
		<link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
		<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" href="../assets/css/styles.css">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		<link rel="stylesheet" type="text/css" href="../assets/css/demo.css">
	</head>
	<body>
	<style> 
	ul.setPaginate {
    display: -ms-flexbox;
    display: flex;
    list-style: none;
    -ms-flex-pack: center!important;
    justify-content: center!important;
    margin-bottom: 30px;
}
ul.setPaginate a {
    display: inline-block;
    padding: 0 8px;
    color: #464646;
}
ul.setPaginate li.setPage {
    margin-right: 9px;
}
	</style>

<div class="tabsList">
<ul class="ulList">
	<li class="tabLi firtsTabLi"><a href="/shopify-app/orders.php?shop=<?php echo $store;?>" class="orderPage">Order List</a></li>
</ul>
</div>
					<div id="plisting" class="tabcontent tapOneDiv">
						<h1 class="listHeading">List Of All Products</h1>
						<div class="searchInnput"><h4 class="searchHead">Search Product:</h4>
						<input type="text"  Placeholder="Enter Product Title" class="searchVal" value="">
						<span class="emptySrch">Field Required!</span></div>
						<div class="loader" style="display:none;"></div>
						<h1 class="Nofound"><span>No Product Found!</span></h1>
						<table style="display:;" class="table_main" border="1">
							<thead>
								<tr class="trtop_gapiheading main_porduct_table">
								<th class="firstTh">Sr No.</th>
								<th class="secondTh">Title</th>
								<th class="thirdTh">Image</th>
								<th class="thirdTh">Donation Description</th>
								<th class="thirdTh">Meals Text</th>
								<th class="thirdTh">Meals Count</th>
								<th class="thirdTh">Action</th>
								</tr>
							</thead>
							<tbody class="productList"> 
							<?php

		

		/* 	$response2 = $client->request(
			'GET', 
			"https://{$store}/admin/products/count.json",
			[
				'query' => [
					'fields' => 'id,vendor,images,title,variants',
					'access_token' => $access_token
				]
			]	
			);
			$result2 = json_decode($response2->getBody()->getContents(), true);
		 $countProducts= $result2['count'];
			if(isset($_GET["page"])){
			$page = (int)$_GET["page"];
			}
			else{
				$page = 1;
			}
			$setLimit = 50; */

			//$pageLimit = ($page * $setLimit) - $setLimit;
/* 			$requestUrl = "https://017645f8607ed5111b8f412fb48a72ce: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@odin-parker.myshopify.com/admin/api/2020-04/products.json?limit=300";
 $response = $client->request('GET', $requestUrl, [
    'headers' => [
        'Content-Type' => 'application/json',
        'Accept' => 'application/json'
     ]
 ]); */
 
			$response2 = $client->request(
			'GET', 
			"https://{$store}/admin/products/count.json",
			[
				'query' => [
					'fields' => 'id,vendor,images,title,variants',
					'access_token' => $access_token
				]
			]	
			);
			$result2 = json_decode($response2->getBody()->getContents(), true);
			$countProducts= $result2['count'];
			if(isset($_GET["page"])){
			$page = (int)$_GET["page"];
			}
			else{
				$page = 1;
			}
			$setLimit = 50;

			$pageLimit = ($page * $setLimit) - $setLimit;
			$response = $client->request(
			'GET', 
			"https://{$store}/admin/products.json",
			[
				'query' => [
					'fields' => 'id,vendor,images,title,variants,inventory_quantity',
					'access_token' => $access_token,
					'limit' => $setLimit,
					'page'=> $page
				]
			]	
		);
		$count=1;
		$result = json_decode($response->getBody()->getContents(), true);
		$i=1;
	/* echo count($result['products']);
   echo "<pre>";
print_r($result);  */
//$products = json_decode($response->getBody()->getContents(), true);
				foreach ($result['products'] as $products_details){ 
			$records_ProductTitle= $products_details['title'];
			$records_ProductTitle = str_replace("'","",$records_ProductTitle);
			$records_ProductTitle = str_replace('"',"",$records_ProductTitle);
		 	$product_handle= $products_details['handle'];
			$records_sku = $products_details['variants'][0]['sku'];
			$product_shopify_VarientsId = $products_details['variants'][0]['id'];
			$product_shopify_VarientsIds = $products_details['variants'];
			$records_Product_Id = $products_details['id'];
			$records_ProductPrice = $products_details['variants'][0]['price'];
			$records_ProductBarcode = $products_details['variants'][0]['barcode'];				
			$product_shopify_title = $products_details['title'];
			$records_image = $products_details['images'][0]['src'];
			
					$results = $db->query("SELECT * FROM product_detail where product_id = '$records_Product_Id'");	
					 if($results->num_rows == 0){
					  	  $ans='insert into product_detail(product_id,product_title,product_handle,product_description,image_src,label_text_area,meals_count,show_text_area,show_on_popup,field_required,exclusion_product,storeName)values("'.$records_Product_Id.'","'.$records_ProductTitle.'","'.$product_handle.'","","'.$records_image.'","","0","","","","","'.$store.'")';	
					
	
						$reslt = mysqli_query($db,$ans);	
						if($reslt){
						//	echo "success";
						}
					 }else{
						$update_sql="UPDATE `product_detail` set product_title='$records_ProductTitle', product_handle ='$product_handle', image_src='$records_image' where  product_id='$records_Product_Id'";
					
						$reslt=mysqli_query($db,$update_sql);	
						if($reslt){
							//echo "Update success";
						}
					 }
					$results = $db->query("SELECT * FROM product_detail where product_id = '$records_Product_Id'");	
					 $row = mysqli_fetch_assoc($results); 
					/*  echo "<pre>";
					 print_r($row);
					 echo "</pre>"; */
					 if($row['product_id']){
					 ?>
									<tr class='trtop_gapi '> 
										<td><?php echo $i;?></td>
										<td class='tdtop_gapi title'><a href="//<?php echo $store; ?>/admin/products/<?php echo $row['product_id']; ?>" target="_blank"><?php echo $row['product_title'];  ?></a></td>
										<td class='tdtop_gapi'><img class="pimageapp" src="<?php echo $row['image_src'];  ?>"></td>
										<td class='tdtop_gapi www'>
										<textarea Placeholder="Enter Product Description" class="prodcutDescription<?php echo $row['id'];?> proDescp"><?php echo $row['product_description']; ?></textarea></td>
										<td class='tdtop_gapi www'>
										<input Placeholder="Enter Textarea Label" type="text" value="<?php echo $row['label_text_area']; ?>" class="label_text<?php echo $row['id'];?> labelText"></td>
										<td class='tdtop_gapi'><input type="number" value="<?php echo $row['meals_count']; ?>" class="character_limit<?php echo $row['id'];?> characterlimit"></td>
										<td><a href="javascript:void(0)" data-proId="<?php echo $row['id'];?>" class="successText<?php echo $row['id'];?> updateData">Update Options</a></td>
									</tr>	

<?php

					 }
				 $i++;	
		 }
			?>
							</tbody>
						</table>
					</div>
					<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<script>
$(document).ready(function(){
	var serverUrl= "http://odin.bestwebdevs.com/shopify-app"
	//Start Exclusion search
				$(document).on('click', '.closeBtn', function(e){
					
					var prodcutMainId = $(this).attr("data-mainid");
					$(".xclusinPrdct"+prodcutMainId).hide();
					var productid = $(this).attr("data-close");
					var p_url = serverUrl+"/exclusion_remove_product.php?shop=<?php echo $store;?> ";
						$.ajax({
							type: "POST",	
							url: p_url,
							data: {MainId:prodcutMainId,pro_id:productid},
							cache: false,
							success: function (data){
								console.log(data);
								if(data == 0){
										$(".xclusinPrdctList"+prodcutMainId).html("");
								}else{
									 $(".Nofound").hide();
									 $(".table_main").show();
									$(".xclusinPrdctList"+prodcutMainId).html("");
									$(".xclusinPrdctList"+prodcutMainId).html(data);
								}
							}
						});
					});
					
					
				$(document).on('click', '.xclusionPrdctsAdd', function(e){
					var prodcutMainId = $(this).attr("data-mainId");
					$(".xclusinPrdct"+prodcutMainId).hide();
					$(".xclusinPrdctList"+prodcutMainId).show();
					prodcutMainId
					var productid = $(this).attr("data-proid");
					var p_url = serverUrl+"/exclusion_add_product.php?shop=<?php echo $store;?> ";
					$.ajax({
						type: "POST",	
						url: p_url,
						data: {MainId:prodcutMainId,pro_id:productid},
						cache: false,
						success: function (data){
							console.log(data);
							if(data == 0){
								$(".xclusinPrdctList"+prodcutMainId).html("");
							}else{
								 $(".Nofound").hide();
								 $(".table_main").show();
								$(".xclusinPrdctList"+prodcutMainId).html("");
								$(".xclusinPrdctList"+prodcutMainId).html(data);
							}
						}
					}); 
				});
		
			$(document).on('keyup', '.exclusionProduct', function(e){
				var proId = $(this).attr("data-proId");
				$(".xclusinPrdct"+proId).show();
			var exclusionProduct = $(this).val();
			console.log(exclusionProduct);
				if(exclusionProduct.trim() == '' ){
					$(".xclusinPrdct"+proId).hide();
					$(".xclusinPrdctList"+proId).show();
					return false;
				}else{
					$(".xclusinPrdctList"+proId).hide();
						$(".xclusinPrdct"+proId).show();
				}
		var p_url = serverUrl+"/exclusion_search_products.php?shop=<?php echo $store;?> ";
			$.ajax({
				type: "POST",	
				url: p_url,
				data: {exclusionLike: exclusionProduct,mainId:proId},
				cache: false,
			   beforeSend: function(){
				// $(".loader").show();
			   },
			   complete: function(){
				 //$(".loader").hide();
			   },
				success: function (data){
					console.log(data);
					if(data == 0){
						$(".xclusinPrdct"+proId).html("No product found!");
					}else{
						 $(".Nofound").hide();
						 $(".table_main").show();
						$(".xclusinPrdct"+proId).html("");
						$(".xclusinPrdct"+proId).html(data);
					}
				}
			}); 
		});
		//end Exclusion search
		$(document).on('click', '.firtsTabLi', function(e){
			$(".tapOneDiv").show();
			$(".tabcontentTwo").hide();
		});
		$(document).on('click', '.secondTabLi', function(e){
			$(".tapOneDiv").hide();
			$(".tabcontentTwo").show();
		});
         $('form.popContentForm').on('submit', function (e) {
			var p_url = serverUrl+"/update_product.php";
			console.log(p_url);
          e.preventDefault();
          $.ajax({
            type: 'post',
            url: p_url,
            data: $('form').serialize(),
			cache: false,
            success: function (data) {
              //console.log(data);
				if(data.trim() == "Updated"){
					
					$(".noticeMsg").html("Form Submitted!");
					
				}else{
					$(".noticeMsgFail").html("Failed!");
					
				}
            }
          });
        }); 
	  
			$(document).on('keyup', '.searchVal', function(e){
			var searchVal = $(this).val();
			console.log(searchVal);
				if(searchVal.trim() == '' ){
					//$(".emptySrch").show();
					return false;
				}else{
				//	$(".emptySrch").hide();
				}
				var p_url = serverUrl+"/search_products.php?shop=<?php echo $store;?> ";
					$.ajax({
						type: "POST",	
						url: p_url,
						data: {searchLike: searchVal},
						cache: false,
					   beforeSend: function(){
						 $(".loader").show();
					   },
					   complete: function(){
						 $(".loader").hide();
					   },
						success: function (data){
							console.log(data);
							if(data == 0){
								$(".Nofound").show();
								$(".table_main").hide();
							}else{
								 $(".Nofound").hide();
								 $(".table_main").show();
								$(".productList").html("");
								$(".productList").html(data);
								
							}
						}
					}); 
		});
	//dearch product end
	$(document).on('click', '.updateData', function(e){
		console.log("dsfdf");
		var  prodID = $(this).attr("data-proId");
		var label_text = $(".label_text"+prodID).val();
		var character_limit = $(".character_limit"+prodID).val();
		var prodcutDescription = $(".prodcutDescription"+prodID).val();
			if($(".show_popup"+prodID).prop("checked") == true){
				var show_popup = "Yes";
			}else{
				var show_popup = "No";
			}
			if($(".showText"+prodID).prop("checked") == true){
			var showText = "Yes";
			}else{
			var showText = "No";
			}
			if($(".field_required"+prodID).prop("checked") == true){
				var field_required = "Yes";
			}else{
			var field_required = "No";
			}
			var p_url = serverUrl+"/update_product.php";
			$.ajax({
				type: "POST",	
				url: p_url,
				data: {productId: prodID,labelText: label_text,characterLimit:character_limit,showTextNote:showText,showPopup:show_popup,fieldRequired:field_required,description:prodcutDescription},
				cache: false,
				success: function (data){
					console.log(data);
					if(data.trim() == "Updated"){
						console.log(data);
						$(".successText"+prodID).html("Done");
							setTimeout(function(){

							$(".successText"+prodID).html("Update Options");

							}, 4000);
					}
				}
			}); 
	});
});
</script>
			<?php
	
		echo displayPaginationBelow($setLimit,$page,$store,$countProducts);
		$template = $twig->loadTemplate('tab.html');
		echo $template->render(['products' => $records ,'listing' => $shop,'api_value' => $form]);

?>

</body>
</html>