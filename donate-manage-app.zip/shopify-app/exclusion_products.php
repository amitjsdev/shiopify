<?php 

//ini_set('display_errors', 1);

ini_set('error_reporting', E_ALL);
       require 'vendor/autoload.php';
	
	use Carbon\Carbon;
	use GuzzleHttp\Client;
	
	$dotenv = new Dotenv\Dotenv(__DIR__);
	$dotenv->load();
	$client = new Client();
	$store =$_GET['shop'];
	$theme_id = "";
	$access_token="";
	
	$db = new Mysqli(getenv('MYSQL_HOST'), getenv('MYSQL_USER'), getenv('MYSQL_PASS'), getenv('MYSQL_DB')); 
	

 $exclusionLike = $_POST["exclusionLike"];
 $mainId = $_POST["mainId"];
			if($exclusionLike != ""){
					$results = $db->query("SELECT * FROM product_detail where storeName = '$store' AND product_title LIKE '%$exclusionLike%'");	
					if($results->num_rows != 0){
						$i=1;
							foreach ($results as $row){ 
								?>
								<span class="xclusionPrdcts" data-mainId="<?php echo $mainId;?>" data-id="<?php echo $row['product_id']; ?>"><?php echo $row['product_title'];  ?><span class="closeBtn" data-mainId="<?php echo $mainId;?>" data-close="<?php echo $row['product_id']; ?>">x</span></span>
								<?php
								$i++;
							}
					}else{
							echo 0;
					}
			}else{
				
				$results2 = $db->query("SELECT * FROM product_detail where storeName = '$store' limit 50");	
					if($results2->num_rows != 0){
							$b=1;
							foreach ($results as $row){ 
								?>
									<tr class='trtop_gapi '> 
										<td><?php echo $b;?></td>
										<td class='tdtop_gapi title'><a href="//<?php echo $store; ?>/admin/products/<?php echo $row['product_id']; ?>" target="_blank"><?php echo $row['product_title'];  ?></a></td>
										<td class='tdtop_gapi'><img class="pimageapp" src="<?php echo $row['image_src'];  ?>"></td>
										<td class='tdtop_gapi www'>
										<input Placeholder="Enter Textarea Label" type="text" value="<?php echo $row['label_text_area']; ?>" class="label_text<?php echo $row['id'];?> labelText"></td>
										<td class='tdtop_gapi'><input type="number" value="<?php echo $row['character_limit']; ?>" class="character_limit<?php echo $row['id'];?> characterlimit"></td>
										<td class='tdtop_gapi'><input type="checkbox" value="Yes"  class="showText<?php echo $row['id'];?> showTextField" <?php if($row['show_text_area'] == "Yes"){ echo "checked"; };?>></td>
										<td class='tdtop_gapi'><input type="checkbox" value="Yes"  class="show_popup<?php echo $row['id'];?> showTextField" <?php if($row['show_on_popup'] == "Yes"){ echo "checked"; };?>></td>
										<td class='tdtop_gapi'><input type="checkbox" value="Yes"  class="field_required<?php echo $row['id'];?> field_required" <?php if($row['field_required'] == "Yes"){ echo "checked"; };?>></td>
											<td><a href="javascript:void(0)" data-proId="<?php echo $row['id'];?>" class="successText<?php echo $row['id'];?> updateData">Update Options</a>
									</tr>	
								<?php
								$b++;
							}
						
					}
			}
							?>