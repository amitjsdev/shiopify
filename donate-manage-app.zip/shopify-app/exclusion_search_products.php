<?php 

//ini_set('display_errors', 1);

header("Access-Control-Allow-Origin: *");

ini_set('error_reporting', E_ALL);
       require 'vendor/autoload.php';
	
	use Carbon\Carbon;
	use GuzzleHttp\Client;
	
	$dotenv = new Dotenv\Dotenv(__DIR__);
	$dotenv->load();
	$client = new Client();
	  $store =$_GET['shop'];
	$theme_id = "";
	$access_token="";
	
	$db = new Mysqli(getenv('MYSQL_HOST'), getenv('MYSQL_USER'), getenv('MYSQL_PASS'), getenv('MYSQL_DB')); 
	

 $exclusionLike = $_POST["exclusionLike"];
 $mainId = $_POST["mainId"];
			if($exclusionLike != ""){
					$results = $db->query("SELECT * FROM product_detail where storeName = '$store' AND product_title LIKE '%$exclusionLike%'");	
					if($results->num_rows != 0){
						$i=1;
							foreach ($results as $row){ 
								?>
								<span class="xclusionPrdctsAdd" data-mainId="<?php echo $mainId;?>" data-proid="<?php echo $row['product_id']; ?>"><?php echo $row['product_title'];  ?></span>
								<?php
								$i++;
							}
					}else{
							echo 0;
					}
			}else{
				echo 0;
			}
							?>