<?php 
echo "test"; 
?>