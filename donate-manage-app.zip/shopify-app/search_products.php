<?php 

//ini_set('display_errors', 1);

header("Access-Control-Allow-Origin: *");

ini_set('error_reporting', E_ALL);
       require 'vendor/autoload.php';
	
	use Carbon\Carbon;
	use GuzzleHttp\Client;
	
	$dotenv = new Dotenv\Dotenv(__DIR__);
	$dotenv->load();
	$client = new Client();
	  $store =$_GET['shop'];
//	 $store ="suffes-dev.myshopify.com";
	
	//$nonce =$_GET['nonce'];
	$theme_id = "";
	$access_token="";
	
	$db = new Mysqli(getenv('MYSQL_HOST'), getenv('MYSQL_USER'), getenv('MYSQL_PASS'), getenv('MYSQL_DB')); 
	

 $searchfor = $_POST["searchLike"];
			if($searchfor != ""){
					$results = $db->query("SELECT * FROM product_detail where storeName = '$store' AND product_title LIKE '%$searchfor%'");	
					if($results->num_rows != 0){
						$i=1;
							foreach ($results as $row){ 
								?>
									<tr class='trtop_gapi '> 
										<td><?php echo $i;?></td>
										<td class='tdtop_gapi title'><a href="//<?php echo $store; ?>/admin/products/<?php echo $row['product_id']; ?>" target="_blank"><?php echo $row['product_title'];  ?></a></td>
										<td class='tdtop_gapi'><img class="pimageapp" src="<?php echo $row['image_src'];  ?>"></td>
										<td class='tdtop_gapi www'>
										<textarea Placeholder="Enter Product Description" class="prodcutDescription<?php echo $row['id'];?> proDescp"><?php echo $row['product_description']; ?></textarea></td>
										<td class='tdtop_gapi www'>
										<input Placeholder="Enter Textarea Label" type="text" value="<?php echo $row['label_text_area']; ?>" class="label_text<?php echo $row['id'];?> labelText"></td>
										<td class='tdtop_gapi'><input type="number" value="<?php echo $row['meals_count']; ?>" class="character_limit<?php echo $row['id'];?> characterlimit"></td>
											<td><a href="javascript:void(0)" data-proId="<?php echo $row['id'];?>" class="successText<?php echo $row['id'];?> updateData">Update Options</a></td>
									</tr>	
								<?php
								$i++;
							}
					}else{
							echo 0;
					}
			}else{
				$results2 = $db->query("SELECT * FROM product_detail where storeName = '$store' limit 50");	
					if($results2->num_rows != 0){
							$b=1;
							foreach ($results as $row){ 
								?>
									<tr class='trtop_gapi '> 
										<td><?php echo $b;?></td>
										<td class='tdtop_gapi title'><a href="//<?php echo $store; ?>/admin/products/<?php echo $row['product_id']; ?>" target="_blank"><?php echo $row['product_title'];  ?></a></td>
										<td class='tdtop_gapi'><img class="pimageapp" src="<?php echo $row['image_src'];  ?>"></td>
										<td class='tdtop_gapi www'>
										<textarea Placeholder="Enter Product Description" class="prodcutDescription<?php echo $row['id'];?> proDescp"><?php echo $row['product_description']; ?></textarea></td>
										<td class='tdtop_gapi www'>
										<input Placeholder="Enter Textarea Label" type="text" value="<?php echo $row['label_text_area']; ?>" class="label_text<?php echo $row['id'];?> labelText"></td>
										<td class='tdtop_gapi'><input type="number" value="<?php echo $row['meals_count']; ?>" class="character_limit<?php echo $row['id'];?> characterlimit"></td>
											<td><a href="javascript:void(0)" data-proId="<?php echo $row['id'];?>" class="successText<?php echo $row['id'];?> updateData">Update Options</a></td>
									</tr>	
								<?php
								$b++;
							}
						
					}
			}
							?>