-- phpMyAdmin SQL Dump
-- version 4.9.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Mar 20, 2020 at 01:11 AM
-- Server version: 5.7.29
-- PHP Version: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shopifya_gift_handwritten_app`
--

-- --------------------------------------------------------

--
-- Table structure for table `installs`
--

CREATE TABLE `installs` (
  `id` int(11) NOT NULL,
  `store` varchar(60) NOT NULL,
  `nonce` varchar(20) NOT NULL,
  `access_token` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `installs`
--

/*INSERT INTO `installs` (`id`, `store`, `nonce`, `access_token`) VALUES
(10, 'test-development-suffes.myshopify.com', '7ZTKJlkTx647eDHqJcn2', '8d098ab623a0aec8fd7d3e7c1b03ffbd'),
(14, 'suffes-dev.myshopify.com', 'gRbPhfS+K6vc2SzGtY5N', 'b5fe2a74134a8490626b2e0cc02f407d'),
(15, 'devtesting21.myshopify.com', 'QAgDt7uJuJ011CQXXK6H', ''),
(16, 'test3325.myshopify.com', 'bpQYP0P/3FRzyG0i7DLq', ''),
(17, 'forvisondev.myshopify.com', 'Uu9xKY6WKEZUPKFlXUWZ', ''),
(18, 'app-test-suffes.myshopify.com', 'WkL59HttM6rJiMbICpOA', '0507210be412ccb18aef563f6bc84ff1'),
(19, 'sir-promotional.myshopify.com', 'MXi2VNVf+MtiArUNcQ7y', ''),
(20, 'apptestsuff.myshopify.com', 'CyKueN0iUojfVl/ryPAe', '75a409b10266c6e706abf9b6751e498b'),
(21, 'apptester21.myshopify.com', 'Bqf27cDaqVJKbnBexn7N', 'd1204e56bc0c1c4d1a06c1ef3c0f9062'),
(22, 'suffescomwe.myshopify.com', '/6lobJLyuC0wbD9nA4lL', 'f6652f07e320da06d3134a1d97553691'),
(23, 'balensiskincare.myshopify.com', 'xZS6S+K6GMD6x1oStSFM', '8149fe753a38aaa09d0b54039a6873ed');*/

-- --------------------------------------------------------

--
-- Table structure for table `popup_detail`
--

CREATE TABLE `popup_detail` (
  `id` int(11) NOT NULL,
  `popupHeading` varchar(255) NOT NULL,
  `popupContent` varchar(255) NOT NULL,
  `disclaimerText` varchar(255) NOT NULL,
  `nothanks` varchar(255) NOT NULL,
  `store_name` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `popup_detail`
--

/*INSERT INTO `popup_detail` (`id`, `popupHeading`, `popupContent`, `disclaimerText`, `nothanks`, `store_name`) VALUES
(1, 'Send a box! ', 'Make someone very happy with our stylish gift boxes and handwritten note cards', 'lorem ipsum is  dummy text', 'No Thanks', 'suffes-dev.myshopify.com'),
(3, 'Send a box!', 'Make someone very happy with our stylish gift boxes and handwritten note cards', 'lorem ipsum is Â dummy text', 'No Thanks', 'apptester21.myshopify.com'),
(4, 'test', 'Make someone very happy with our stylish gift boxes and handwritten note cards', 'lorem ipsum is  dummy text', 'No Thanks', 'apptestsuff.myshopify.com'),
(5, 'Send a box!', 'Make someone very happy with our stylish gift boxes and handwritten note cards', 'lorem ipsum is Â dummy text sdf fs', 'No Thanks', 'suffescomwe.myshopify.com');*/

-- --------------------------------------------------------

--
-- Table structure for table `product_detail`
--

CREATE TABLE `product_detail` (
  `id` int(11) NOT NULL,
  `product_id` varchar(255) NOT NULL,
  `product_title` varchar(255) NOT NULL,
  `product_handle` varchar(255) NOT NULL,
  `product_description` varchar(255) NOT NULL,
  `image_src` varchar(255) NOT NULL,
  `label_text_area` varchar(255) NOT NULL,
  `character_limit` varchar(10000) NOT NULL,
  `show_text_area` varchar(255) NOT NULL,
  `show_on_popup` varchar(255) NOT NULL,
  `field_required` varchar(255) NOT NULL,
  `exclusion_product` longtext NOT NULL,
  `storeName` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_detail`
--

/*INSERT INTO `product_detail` (`id`, `product_id`, `product_title`, `product_handle`, `product_description`, `image_src`, `label_text_area`, `character_limit`, `show_text_area`, `show_on_popup`, `field_required`, `exclusion_product`, `storeName`) VALUES
(198, '4430288617523', 'Silver Patterned Band Ring - 4mm - F5491-Q', 'silver-patterned-band-ring-4mm-f5491-q', '', 'https://cdn.shopify.com/s/files/1/0096/8445/1379/products/F5491_L_1.jpg?v=1579669816', 'Craft your note!', '150', '', '', '', '', 'suffes-dev.myshopify.com'),
(197, '4430287732787', 'Silver Light Blue Resin And Crystal Flower Earrings - 8mm - F0464', 'silver-light-blue-resin-and-crystal-flower-earrings-8mm-f0464', '', 'https://cdn.shopify.com/s/files/1/0096/8445/1379/products/F0464_L_1.jpg?v=1579669791', 'Craft your note!', '150', '', '', '', '', 'suffes-dev.myshopify.com'),
(196, '4430288781363', 'Silver Gecko Stud Earrings - 7mm - F0108', 'silver-gecko-stud-earrings-7mm-f0108', '', 'https://cdn.shopify.com/s/files/1/0096/8445/1379/products/F0108_L_1.jpg?v=1579669822', 'Craft your note!', '150', '', '', '', '', 'suffes-dev.myshopify.com'),
(195, '4430288355379', 'Silver Double Strand Crossover Ring - F5471-R', 'silver-double-strand-crossover-ring-f5471-r', '', 'https://cdn.shopify.com/s/files/1/0096/8445/1379/products/F5471_L_1.jpg?v=1579669809', 'Craft your note!', '150', '', '', '', '', 'suffes-dev.myshopify.com'),
(194, '4430288126003', 'Silver Diamond Cut Hoop Earrings - 25mm - F1346', 'silver-diamond-cut-hoop-earrings-25mm-f1346', '', 'https://cdn.shopify.com/s/files/1/0096/8445/1379/products/F1346_L_1.jpg?v=1579669803', 'Craft your note!', '150', '', '', '', '', 'suffes-dev.myshopify.com'),
(193, '4430288912435', 'Silver Cubic Zirconia Two Hearts Necklace - F3497', 'silver-cubic-zirconia-two-hearts-necklace-f3497', '', 'https://cdn.shopify.com/s/files/1/0096/8445/1379/products/F3497_L_1.jpg?v=1579669828', 'Craft your note!', '150', '', '', '', '', 'suffes-dev.myshopify.com'),
(192, '4430289272883', 'Silver Cubic Zirconia Trilogy Pendant And Chain - F3439', 'silver-cubic-zirconia-trilogy-pendant-and-chain-f3439', '', 'https://cdn.shopify.com/s/files/1/0096/8445/1379/products/F3439_L_1.jpg?v=1579669843', 'Craft your note!', '150', '', '', '', '', 'suffes-dev.myshopify.com'),
(191, '4430289403955', 'Silver Cubic Zirconia Tendril Drop Earrings - 25mm drop - F1106', 'silver-cubic-zirconia-tendril-drop-earrings-25mm-drop-f1106', '', 'https://cdn.shopify.com/s/files/1/0096/8445/1379/products/F1106_L_1.jpg?v=1579669849', 'Craft your note!', '150', '', '', '', '', 'suffes-dev.myshopify.com'),
(190, '4430289305651', 'Silver Cubic Zirconia Leaf Drop Earrings - 20mm drop - F1102', 'silver-cubic-zirconia-leaf-drop-earrings-20mm-drop-f1102', '', 'https://cdn.shopify.com/s/files/1/0096/8445/1379/products/F1102_L_1.jpg?v=1579669845', 'Craft your note!', '150', '', '', '', '', 'suffes-dev.myshopify.com'),
(189, '4430288814131', 'Silver Cubic Zirconia Knot Stud Earrings - 10mm - F0463', 'silver-cubic-zirconia-knot-stud-earrings-10mm-f0463', '', 'https://cdn.shopify.com/s/files/1/0096/8445/1379/products/F0463_L_1.jpg?v=1579669824', 'Craft your note!', '150', '', '', '', '', 'suffes-dev.myshopify.com'),
(188, '4430287831091', 'Silver Cubic Zirconia Floating Heart Pendant And Chain - F3458', 'silver-cubic-zirconia-floating-heart-pendant-and-chain-f3458', '', 'https://cdn.shopify.com/s/files/1/0096/8445/1379/products/F3458_L_1.jpg?v=1579669793', 'Craft your note!', '150', '', '', '', '', 'suffes-dev.myshopify.com'),
(187, '4430289076275', 'Silver Cubic Zirconia Double Heart Necklace - F3501', 'silver-cubic-zirconia-double-heart-necklace-f3501', '', 'https://cdn.shopify.com/s/files/1/0096/8445/1379/products/F3501_L_1.jpg?v=1579669834', 'Craft your note!', '150', '', '', '', '', 'suffes-dev.myshopify.com'),
(186, '4430289666099', 'Silver Cubic Zirconia Crossover Ring - F5962-P', 'silver-cubic-zirconia-crossover-ring-f5962-p', '', 'https://cdn.shopify.com/s/files/1/0096/8445/1379/products/F5962_L_1_816da653-cae0-4ca7-9bd8-404f4279f692.jpg?v=1579669861', 'Craft your note!', '150', '', '', '', '', 'suffes-dev.myshopify.com'),
(185, '4430289633331', 'Silver Cubic Zirconia Crossover Ring - F5962-O', 'silver-cubic-zirconia-crossover-ring-f5962-o', '', 'https://cdn.shopify.com/s/files/1/0096/8445/1379/products/F5962_L_1_c93295f1-934a-4b59-a115-7e77cf8d8249.jpg?v=1579669859', 'Craft your note!', '150', '', '', '', '', 'suffes-dev.myshopify.com'),
(184, '4430289567795', 'Silver Cubic Zirconia Crossover Ring - F5962-N', 'silver-cubic-zirconia-crossover-ring-f5962-n', '', 'https://cdn.shopify.com/s/files/1/0096/8445/1379/products/F5962_L_1_dcd88101-4a77-4de1-be07-29641cef5695.jpg?v=1579669857', 'Craft your note!', '150', '', '', '', '', 'suffes-dev.myshopify.com'),
(183, '4430289535027', 'Silver Cubic Zirconia Crossover Ring - F5962-M', 'silver-cubic-zirconia-crossover-ring-f5962-m', '', 'https://cdn.shopify.com/s/files/1/0096/8445/1379/products/F5962_L_1_ea213597-d274-4f61-ac0b-402fe664563e.jpg?v=1579669855', 'Craft your note!', '150', '', '', '', '', 'suffes-dev.myshopify.com'),
(182, '4430289502259', 'Silver Cubic Zirconia Crossover Ring - F5962-L', 'silver-cubic-zirconia-crossover-ring-f5962-l', '', 'https://cdn.shopify.com/s/files/1/0096/8445/1379/products/F5962_L_1.jpg?v=1579669853', 'Craft your note!', '150', '', '', '', '', 'suffes-dev.myshopify.com'),
(181, '4430290386995', 'Silver Cubic Zirconia Cluster Ring - F5970-R', 'silver-cubic-zirconia-cluster-ring-f5970-r', '', 'https://cdn.shopify.com/s/files/1/0096/8445/1379/products/F5970_L_1_6a04c834-1800-4e19-864f-b0c817574c52.jpg?v=1579669891', 'Craft your note!', '150', '', '', '', '', 'suffes-dev.myshopify.com'),
(180, '4430290288691', 'Silver Cubic Zirconia Cluster Ring - F5970-Q', 'silver-cubic-zirconia-cluster-ring-f5970-q', '', 'https://cdn.shopify.com/s/files/1/0096/8445/1379/products/F5970_L_1_a01be482-10ff-41af-9a4c-829dce34507c.jpg?v=1579669889', 'Craft your note!', '150', '', '', '', '', 'suffes-dev.myshopify.com'),
(179, '4430290255923', 'Silver Cubic Zirconia Cluster Ring - F5970-P', 'silver-cubic-zirconia-cluster-ring-f5970-p', '', 'https://cdn.shopify.com/s/files/1/0096/8445/1379/products/F5970_L_1_69f1a259-afb3-483f-926b-63662524337c.jpg?v=1579669887', 'Craft your note!', '150', '', '', '', '', 'suffes-dev.myshopify.com'),
(178, '4430290223155', 'Silver Cubic Zirconia Cluster Ring - F5970-O', 'silver-cubic-zirconia-cluster-ring-f5970-o', '', 'https://cdn.shopify.com/s/files/1/0096/8445/1379/products/F5970_L_1_d6759cbd-7404-43a7-b0e3-e91c41f511e1.jpg?v=1579669885', 'Craft your note!', '150', '', '', '', '', 'suffes-dev.myshopify.com'),
(177, '4430290157619', 'Silver Cubic Zirconia Cluster Ring - F5970-N', 'silver-cubic-zirconia-cluster-ring-f5970-n', '', 'https://cdn.shopify.com/s/files/1/0096/8445/1379/products/F5970_L_1_b12b7133-1166-455b-9636-68cfc532f4f0.jpg?v=1579669884', 'Craft your note!', '150', '', '', '', '', 'suffes-dev.myshopify.com'),
(176, '4430290092083', 'Silver Cubic Zirconia Cluster Ring - F5970-M', 'silver-cubic-zirconia-cluster-ring-f5970-m', '', 'https://cdn.shopify.com/s/files/1/0096/8445/1379/products/F5970_L_1.jpg?v=1579669882', 'Craft your note!', '150', '', '', '', '', 'suffes-dev.myshopify.com'),
(175, '4430287962163', 'Silver Cubic Zirconia And Freshwater Pearl Hook Wire Drop Earrings - 30mm - F0776', 'silver-cubic-zirconia-and-freshwater-pearl-hook-wire-drop-earrings-30mm-f0776', '', 'https://cdn.shopify.com/s/files/1/0096/8445/1379/products/F0776_L_1.jpg?v=1579669799', 'Craft your note!', '150', '', '', '', '', 'suffes-dev.myshopify.com'),
(174, '4430290059315', 'Silver Crystal Cross Stud Earrings - 15mm drop - F1151', 'silver-crystal-cross-stud-earrings-15mm-drop-f1151', '', 'https://cdn.shopify.com/s/files/1/0096/8445/1379/products/F1151_L_1.jpg?v=1579669880', 'Craft your note!', '150', '', '', '', '', 'suffes-dev.myshopify.com'),
(173, '4430288683059', 'Silver Celtic Ring - F5532-P', 'silver-celtic-ring-f5532-p', '', 'https://cdn.shopify.com/s/files/1/0096/8445/1379/products/F5532_L_1.jpg?v=1579669818', 'Craft your note!', '150', '', '', '', '', 'suffes-dev.myshopify.com'),
(172, '4430288748595', 'Platinum Diamond Solitaire Ring - 20pts - AGI Certificated - D0813-K', 'platinum-diamond-solitaire-ring-20pts-agi-certificated-d0813-k', '', 'https://cdn.shopify.com/s/files/1/0096/8445/1379/products/D0813_L_1.jpg?v=1579669820', 'Craft your note!', '150', '', '', '', '', 'suffes-dev.myshopify.com'),
(171, '4430289764403', 'D For Diamond Silver Diamond Set Heart Expandable Baby Bangle - D8511', 'd-for-diamond-silver-diamond-set-heart-expandable-baby-bangle-d8511', '', 'https://cdn.shopify.com/s/files/1/0096/8445/1379/products/D8511_L_1.jpg?v=1579669865', 'Craft your note!', '150', '', '', '', '', 'suffes-dev.myshopify.com'),
(170, '4430288879667', '9ct White Gold Diamond Open Crossover Ring - 10pts - D7010-A', '9ct-white-gold-diamond-open-crossover-ring-10pts-d7010-a', '', 'https://cdn.shopify.com/s/files/1/0096/8445/1379/products/D7010_L_1.jpg?v=1579669826', 'Craft your note!', '150', '', '', '', '', 'suffes-dev.myshopify.com'),
(169, '4430287896627', '9ct White Gold Diamond Half Eternity Ring - 1/4ct - D7174-S', '9ct-white-gold-diamond-half-eternity-ring-1-4ct-d7174-s', '', 'https://cdn.shopify.com/s/files/1/0096/8445/1379/products/D7174_L_1.jpg?v=1579669795', 'Craft your note!', '150', '', '', '', '', 'suffes-dev.myshopify.com'),
(168, '4430287667251', '9ct White Gold Ball Stud Earrings - 5mm - G0692', '9ct-white-gold-ball-stud-earrings-5mm-g0692', '', 'https://cdn.shopify.com/s/files/1/0096/8445/1379/products/G0692_L_1.jpg?v=1579669787', 'Craft your note!', '150', '', '', '', '', 'suffes-dev.myshopify.com'),
(167, '4430287601715', '9ct Two Colour Gold Blue Topaz And Diamond Stud Earrings - 13mm - G0684', '9ct-two-colour-gold-blue-topaz-and-diamond-stud-earrings-13mm-g0684', '', 'https://cdn.shopify.com/s/files/1/0096/8445/1379/products/G0684_L_1.jpg?v=1579669785', 'Craft your note!', '150', '', '', '', '', 'suffes-dev.myshopify.com'),
(166, '4430287929395', '9ct Gold Two Colour Open Heart Stud Earrings - 8mm - G0143', '9ct-gold-two-colour-open-heart-stud-earrings-8mm-g0143', '', 'https://cdn.shopify.com/s/files/1/0096/8445/1379/products/G0143_L_1.jpg?v=1579669797', 'Craft your note!', '150', '', '', '', '', 'suffes-dev.myshopify.com'),
(165, '4430289141811', '9ct Gold Two Colour Loop Stud Earrings - 10mm - G0120', '9ct-gold-two-colour-loop-stud-earrings-10mm-g0120', '', 'https://cdn.shopify.com/s/files/1/0096/8445/1379/products/G0120_L_1.jpg?v=1579669837', 'Craft your note!', '150', '', '', '', '', 'suffes-dev.myshopify.com'),
(164, '4430289436723', '9ct Gold Two Colour Black Sapphire And Diamond Heart Stud Earrings - 6mm - G0230', '9ct-gold-two-colour-black-sapphire-and-diamond-heart-stud-earrings-6mm-g0230', '', 'https://cdn.shopify.com/s/files/1/0096/8445/1379/products/G0230_L_1.jpg?v=1579669851', 'Craft your note!', '150', '', '', '', '', 'suffes-dev.myshopify.com'),
(163, '4430289240115', '9ct Gold Star Earrings - 7mm - G0221', '9ct-gold-star-earrings-7mm-g0221', '', 'https://cdn.shopify.com/s/files/1/0096/8445/1379/products/G0221_L_1.jpg?v=1579669841', 'Craft your note!', '150', '', '', '', '', 'suffes-dev.myshopify.com'),
(162, '4430289174579', '9ct Gold Facetted Flower Earrings - G0220', '9ct-gold-facetted-flower-earrings-g0220', '', 'https://cdn.shopify.com/s/files/1/0096/8445/1379/products/G0220_L_1.jpg?v=1579669839', 'Craft your note!', '150', 'Yes', 'Yes', 'Yes', '', 'suffes-dev.myshopify.com'),
(161, '4430288060467', '9ct Gold Diamond Heart Necklace - 5pts - D5608', '9ct-gold-diamond-heart-necklace-5pts-d5608', '', 'https://cdn.shopify.com/s/files/1/0096/8445/1379/products/D5608_L_1.jpg?v=1579669801', 'Craft your note!', '150', 'Yes', 'Yes', 'Yes', '', 'suffes-dev.myshopify.com'),
(160, '4430289109043', '9ct Gold Amethyst Teardrop Stud Earrings - 7mm - G0416', '9ct-gold-amethyst-teardrop-stud-earrings-7mm-g0416', '', 'https://cdn.shopify.com/s/files/1/0096/8445/1379/products/G0416_L_1.jpg?v=1579669835', 'Craft your note!', '150', 'Yes', 'Yes', 'Yes', '', 'suffes-dev.myshopify.com'),
(159, '4430288945203', '18ct White Gold Diamond Solitaire Ring - 60pts - Certificated - D2306-O', '18ct-white-gold-diamond-solitaire-ring-60pts-certificated-d2306-o', '', 'https://cdn.shopify.com/s/files/1/0096/8445/1379/products/D2306_L_1.jpg?v=1579669830', 'Craft your note!', '150', 'Yes', 'Yes', 'Yes', '', 'suffes-dev.myshopify.com'),
(117, '4690882494601', 'Silver Patterned Band Ring - 4mm - F5491-Q', 'silver-patterned-band-ring-4mm-f5491-q', '', 'https://cdn.shopify.com/s/files/1/0359/1674/2793/products/F5491_L_1.jpg?v=1584521556', '', '', '', '', '', '', 'apptester21.myshopify.com'),
(116, '4690881282185', 'Silver Light Blue Resin And Crystal Flower Earrings - 8mm - F0464', 'silver-light-blue-resin-and-crystal-flower-earrings-8mm-f0464', '', 'https://cdn.shopify.com/s/files/1/0359/1674/2793/products/F0464_L_1.jpg?v=1584521539', '', '', '', '', '', '', 'apptester21.myshopify.com'),
(115, '4690882789513', 'Silver Gecko Stud Earrings - 7mm - F0108', 'silver-gecko-stud-earrings-7mm-f0108', '', 'https://cdn.shopify.com/s/files/1/0359/1674/2793/products/F0108_L_1.jpg?v=1584521559', '', '', '', '', '', '', 'apptester21.myshopify.com'),
(114, '4690882429065', 'Silver Double Strand Crossover Ring - F5471-R', 'silver-double-strand-crossover-ring-f5471-r', '', 'https://cdn.shopify.com/s/files/1/0359/1674/2793/products/F5471_L_1.jpg?v=1584521554', '', '', '', '', '', '', 'apptester21.myshopify.com'),
(113, '4690882035849', 'Silver Diamond Cut Hoop Earrings - 25mm - F1346', 'silver-diamond-cut-hoop-earrings-25mm-f1346', '', 'https://cdn.shopify.com/s/files/1/0359/1674/2793/products/F1346_L_1.jpg?v=1584521549', '', '', '', '', '', '', 'apptester21.myshopify.com'),
(112, '4690883215497', 'Silver Cubic Zirconia Two Hearts Necklace - F3497', 'silver-cubic-zirconia-two-hearts-necklace-f3497', '', 'https://cdn.shopify.com/s/files/1/0359/1674/2793/products/F3497_L_1.jpg?v=1584521564', '', '', '', '', '', '', 'apptester21.myshopify.com'),
(111, '4690884067465', 'Silver Cubic Zirconia Trilogy Pendant And Chain - F3439', 'silver-cubic-zirconia-trilogy-pendant-and-chain-f3439', '', 'https://cdn.shopify.com/s/files/1/0359/1674/2793/products/F3439_L_1.jpg?v=1584521575', '', '', '', '', '', '', 'apptester21.myshopify.com'),
(110, '4690884329609', 'Silver Cubic Zirconia Tendril Drop Earrings - 25mm drop - F1106', 'silver-cubic-zirconia-tendril-drop-earrings-25mm-drop-f1106', '', 'https://cdn.shopify.com/s/files/1/0359/1674/2793/products/F1106_L_1.jpg?v=1584521578', '', '', '', '', '', '', 'apptester21.myshopify.com'),
(109, '4690884231305', 'Silver Cubic Zirconia Leaf Drop Earrings - 20mm drop - F1102', 'silver-cubic-zirconia-leaf-drop-earrings-20mm-drop-f1102', '', 'https://cdn.shopify.com/s/files/1/0359/1674/2793/products/F1102_L_1.jpg?v=1584521577', '', '', '', '', '', '', 'apptester21.myshopify.com'),
(108, '4690882953353', 'Silver Cubic Zirconia Knot Stud Earrings - 10mm - F0463', 'silver-cubic-zirconia-knot-stud-earrings-10mm-f0463', '', 'https://cdn.shopify.com/s/files/1/0359/1674/2793/products/F0463_L_1.jpg?v=1584521561', '', '', '', '', '', '', 'apptester21.myshopify.com'),
(107, '4690881446025', 'Silver Cubic Zirconia Floating Heart Pendant And Chain - F3458', 'silver-cubic-zirconia-floating-heart-pendant-and-chain-f3458', '', 'https://cdn.shopify.com/s/files/1/0359/1674/2793/products/F3458_L_1.jpg?v=1584521541', '', '', '', '', '', '', 'apptester21.myshopify.com'),
(106, '4690883412105', 'Silver Cubic Zirconia Double Heart Necklace - F3501', 'silver-cubic-zirconia-double-heart-necklace-f3501', '', 'https://cdn.shopify.com/s/files/1/0359/1674/2793/products/F3501_L_1.jpg?v=1584521566', '', '', '', '', '', '', 'apptester21.myshopify.com'),
(105, '4690884984969', 'Silver Cubic Zirconia Crossover Ring - F5962-P', 'silver-cubic-zirconia-crossover-ring-f5962-p', '', 'https://cdn.shopify.com/s/files/1/0359/1674/2793/products/F5962_L_1_816da653-cae0-4ca7-9bd8-404f4279f692.jpg?v=1584521589', '', '', '', '', '', '', 'apptester21.myshopify.com'),
(104, '4690884886665', 'Silver Cubic Zirconia Crossover Ring - F5962-O', 'silver-cubic-zirconia-crossover-ring-f5962-o', '', 'https://cdn.shopify.com/s/files/1/0359/1674/2793/products/F5962_L_1_c93295f1-934a-4b59-a115-7e77cf8d8249.jpg?v=1584521587', '', '', '', '', '', '', 'apptester21.myshopify.com'),
(103, '4690884821129', 'Silver Cubic Zirconia Crossover Ring - F5962-N', 'silver-cubic-zirconia-crossover-ring-f5962-n', '', 'https://cdn.shopify.com/s/files/1/0359/1674/2793/products/F5962_L_1_dcd88101-4a77-4de1-be07-29641cef5695.jpg?v=1584521585', '', '', '', '', '', '', 'apptester21.myshopify.com'),
(102, '4690884657289', 'Silver Cubic Zirconia Crossover Ring - F5962-M', 'silver-cubic-zirconia-crossover-ring-f5962-m', '', 'https://cdn.shopify.com/s/files/1/0359/1674/2793/products/F5962_L_1_ea213597-d274-4f61-ac0b-402fe664563e.jpg?v=1584521584', '', '', '', '', '', '', 'apptester21.myshopify.com'),
(101, '4690884591753', 'Silver Cubic Zirconia Crossover Ring - F5962-L', 'silver-cubic-zirconia-crossover-ring-f5962-l', '', 'https://cdn.shopify.com/s/files/1/0359/1674/2793/products/F5962_L_1.jpg?v=1584521582', '', '', '', '', '', '', 'apptester21.myshopify.com'),
(100, '4690886525065', 'Silver Cubic Zirconia Cluster Ring - F5970-R', 'silver-cubic-zirconia-cluster-ring-f5970-r', '', 'https://cdn.shopify.com/s/files/1/0359/1674/2793/products/F5970_L_1_6a04c834-1800-4e19-864f-b0c817574c52.jpg?v=1584521606', '', '', '', '', '', '', 'apptester21.myshopify.com'),
(99, '4690886393993', 'Silver Cubic Zirconia Cluster Ring - F5970-N', 'silver-cubic-zirconia-cluster-ring-f5970-n', '', 'https://cdn.shopify.com/s/files/1/0359/1674/2793/products/F5970_L_1_b12b7133-1166-455b-9636-68cfc532f4f0.jpg?v=1584521604', '', '', '', '', '', '', 'apptester21.myshopify.com'),
(98, '4690886295689', 'Silver Crystal Cross Stud Earrings - 15mm drop - F1151', 'silver-crystal-cross-stud-earrings-15mm-drop-f1151', '', 'https://cdn.shopify.com/s/files/1/0359/1674/2793/products/F1151_L_1.jpg?v=1584521603', '', '', '', '', '', '', 'apptester21.myshopify.com'),
(97, '4690882625673', 'Silver Celtic Ring - F5532-P', 'silver-celtic-ring-f5532-p', '', 'https://cdn.shopify.com/s/files/1/0359/1674/2793/products/F5532_L_1.jpg?v=1584521557', '', '', '', '', '', '', 'apptester21.myshopify.com'),
(96, '4690882691209', 'Platinum Diamond Solitaire Ring - 20pts - AGI Certificated - D0813-K', 'platinum-diamond-solitaire-ring-20pts-agi-certificated-d0813-k', '', 'https://cdn.shopify.com/s/files/1/0359/1674/2793/products/D0813_L_1.jpg?v=1584521558', '', '', '', '', '', '', 'apptester21.myshopify.com'),
(95, '4690885247113', 'D For Diamond Silver Diamond Set Heart Expandable Baby Bangle - D8511', 'd-for-diamond-silver-diamond-set-heart-expandable-baby-bangle-d8511', '', 'https://cdn.shopify.com/s/files/1/0359/1674/2793/products/D8511_L_1.jpg?v=1584521592', '', '', '', '', '', '', 'apptester21.myshopify.com'),
(94, '4690883084425', '9ct White Gold Diamond Open Crossover Ring - 10pts - D7010-A', '9ct-white-gold-diamond-open-crossover-ring-10pts-d7010-a', '', 'https://cdn.shopify.com/s/files/1/0359/1674/2793/products/D7010_L_1.jpg?v=1584521562', '', '', '', '', '', '', 'apptester21.myshopify.com'),
(93, '4690881577097', '9ct White Gold Diamond Half Eternity Ring - 1/4ct - D7174-S', '9ct-white-gold-diamond-half-eternity-ring-1-4ct-d7174-s', '', 'https://cdn.shopify.com/s/files/1/0359/1674/2793/products/D7174_L_1.jpg?v=1584521543', '', '', '', '', '', '', 'apptester21.myshopify.com'),
(92, '4690880921737', '9ct White Gold Ball Stud Earrings - 5mm - G0692', '9ct-white-gold-ball-stud-earrings-5mm-g0692', '', 'https://cdn.shopify.com/s/files/1/0359/1674/2793/products/G0692_L_1.jpg?v=1584521535', '', '', '', '', '', '', 'apptester21.myshopify.com'),
(91, '4690880757897', '9ct Two Colour Gold Blue Topaz And Diamond Stud Earrings - 13mm - G0684', '9ct-two-colour-gold-blue-topaz-and-diamond-stud-earrings-13mm-g0684', '', 'https://cdn.shopify.com/s/files/1/0359/1674/2793/products/G0684_L_1.jpg?v=1584521533', '', '', '', '', '', '', 'apptester21.myshopify.com'),
(90, '4690881642633', '9ct Gold Two Colour Open Heart Stud Earrings - 8mm - G0143', '9ct-gold-two-colour-open-heart-stud-earrings-8mm-g0143', '', 'https://cdn.shopify.com/s/files/1/0359/1674/2793/products/G0143_L_1.jpg?v=1584521545', '', '', '', '', '', '', 'apptester21.myshopify.com'),
(89, '4690883772553', '9ct Gold Two Colour Loop Stud Earrings - 10mm - G0120', '9ct-gold-two-colour-loop-stud-earrings-10mm-g0120', '', 'https://cdn.shopify.com/s/files/1/0359/1674/2793/products/G0120_L_1.jpg?v=1584521571', '', '', '', '', '', '', 'apptester21.myshopify.com'),
(88, '4690884493449', '9ct Gold Two Colour Black Sapphire And Diamond Heart Stud Earrings - 6mm - G0230', '9ct-gold-two-colour-black-sapphire-and-diamond-heart-stud-earrings-6mm-g0230', '', 'https://cdn.shopify.com/s/files/1/0359/1674/2793/products/G0230_L_1.jpg?v=1584521580', '', '', '', '', '', '', 'apptester21.myshopify.com'),
(87, '4690884001929', '9ct Gold Star Earrings - 7mm - G0221', '9ct-gold-star-earrings-7mm-g0221', '', 'https://cdn.shopify.com/s/files/1/0359/1674/2793/products/G0221_L_1.jpg?v=1584521574', '', '', '', '', '', '', 'apptester21.myshopify.com'),
(86, '4690883838089', '9ct Gold Facetted Flower Earrings - G0220', '9ct-gold-facetted-flower-earrings-g0220', '', 'https://cdn.shopify.com/s/files/1/0359/1674/2793/products/G0220_L_1.jpg?v=1584521573', 'Product Note', '70', 'Yes', 'Yes', 'Yes', '', 'apptester21.myshopify.com'),
(85, '4690881872009', '9ct Gold Diamond Heart Necklace - 5pts - D5608', '9ct-gold-diamond-heart-necklace-5pts-d5608', '', 'https://cdn.shopify.com/s/files/1/0359/1674/2793/products/D5608_L_1.jpg?v=1584521547', '', '', '', '', '', '', 'apptester21.myshopify.com'),
(84, '4690883543177', '9ct Gold Amethyst Teardrop Stud Earrings - 7mm - G0416', '9ct-gold-amethyst-teardrop-stud-earrings-7mm-g0416', 'Product Description', 'https://cdn.shopify.com/s/files/1/0359/1674/2793/products/G0416_L_1.jpg?v=1584521568', 'Product Note', '100', 'Yes', 'Yes', 'Yes', '', 'apptester21.myshopify.com'),
(83, '4690883313801', '18ct White Gold Diamond Solitaire Ring - 60pts - Certificated - D2306-O', '18ct-white-gold-diamond-solitaire-ring-60pts-certificated-d2306-o', '', 'https://cdn.shopify.com/s/files/1/0359/1674/2793/products/D2306_L_1.jpg?v=1584521565', 'Product Note', '150', 'Yes', 'Yes', 'Yes', '', 'apptester21.myshopify.com'),
(118, '4690881151113', 'Silver Pink And Blue Seahorse Earrings - 10mm - F0409', 'silver-pink-and-blue-seahorse-earrings-10mm-f0409', '', 'https://cdn.shopify.com/s/files/1/0359/1674/2793/products/F0409_L_1.jpg?v=1584521537', '', '', '', '', '', '', 'apptester21.myshopify.com'),
(119, '4690882330761', 'Silver Plaited Revolving Band Ring - 8mm - F4815-X', 'silver-plaited-revolving-band-ring-8mm-f4815-x', '', 'https://cdn.shopify.com/s/files/1/0359/1674/2793/products/F4815_L_1.jpg?v=1584521553', '', '', '', '', '', '', 'apptester21.myshopify.com'),
(120, '4690882265225', 'Silver Prince Of Wales Feathers Ring - F4953-W', 'silver-prince-of-wales-feathers-ring-f4953-w', '', 'https://cdn.shopify.com/s/files/1/0359/1674/2793/products/F4953_L_1.jpg?v=1584521552', '', '', '', '', '', '', 'apptester21.myshopify.com'),
(121, '4774733840429', '9ct Two Colour Gold Blue Topaz And Diamond Stud Earrings - 13mm - G0684', '9ct-two-colour-gold-blue-topaz-and-diamond-stud-earrings-13mm-g0684', '', 'https://cdn.shopify.com/s/files/1/0367/2447/3901/products/G0684_L_1.jpg?v=1584595416', '', '', '', '', '', '', 'apptestsuff.myshopify.com'),
(122, '4774733938733', '9ct White Gold Ball Stud Earrings - 5mm - G0692', '9ct-white-gold-ball-stud-earrings-5mm-g0692', '', 'https://cdn.shopify.com/s/files/1/0367/2447/3901/products/G0692_L_1.jpg?v=1584595417', '', '', '', '', '', '', 'apptestsuff.myshopify.com'),
(123, '4774734102573', 'Silver Pink And Blue Seahorse Earrings - 10mm - F0409', 'silver-pink-and-blue-seahorse-earrings-10mm-f0409', '', 'https://cdn.shopify.com/s/files/1/0367/2447/3901/products/F0409_L_1.jpg?v=1584595418', '', '', '', '', '', '', 'apptestsuff.myshopify.com'),
(124, '4774735544365', '18ct White Gold Diamond Solitaire Ring - 60pts - Certificated - D2306-O', '18ct-white-gold-diamond-solitaire-ring-60pts-certificated-d2306-o', '', 'https://cdn.shopify.com/s/files/1/0367/2447/3901/products/D2306_L_1.jpg?v=1584595439', 'ghuj', '12', 'Yes', 'Yes', 'Yes', '[\"4774733938733\"]', 'apptestsuff.myshopify.com'),
(125, '4774735708205', '9ct Gold Amethyst Teardrop Stud Earrings - 7mm - G0416', '9ct-gold-amethyst-teardrop-stud-earrings-7mm-g0416', '', 'https://cdn.shopify.com/s/files/1/0367/2447/3901/products/G0416_L_1.jpg?v=1584595442', '', '', 'Yes', 'Yes', 'Yes', '', 'apptestsuff.myshopify.com'),
(126, '4774734528557', '9ct Gold Diamond Heart Necklace - 5pts - D5608', '9ct-gold-diamond-heart-necklace-5pts-d5608', '', 'https://cdn.shopify.com/s/files/1/0367/2447/3901/products/D5608_L_1.jpg?v=1584595425', '', '', 'Yes', 'Yes', 'Yes', '', 'apptestsuff.myshopify.com'),
(127, '4774736003117', '9ct Gold Facetted Flower Earrings - G0220', '9ct-gold-facetted-flower-earrings-g0220', '', 'https://cdn.shopify.com/s/files/1/0367/2447/3901/products/G0220_L_1.jpg?v=1584595448', '', '', '', '', '', '', 'apptestsuff.myshopify.com'),
(128, '4774736101421', '9ct Gold Star Earrings - 7mm - G0221', '9ct-gold-star-earrings-7mm-g0221', '', 'https://cdn.shopify.com/s/files/1/0367/2447/3901/products/G0221_L_1.jpg?v=1584595450', '', '', '', '', '', '', 'apptestsuff.myshopify.com'),
(129, '4774735904813', '9ct Gold Two Colour Loop Stud Earrings - 10mm - G0120', '9ct-gold-two-colour-loop-stud-earrings-10mm-g0120', '', 'https://cdn.shopify.com/s/files/1/0367/2447/3901/products/G0120_L_1.jpg?v=1584595446', '', '', '', '', '', '', 'apptestsuff.myshopify.com'),
(130, '4774734463021', '9ct Gold Two Colour Open Heart Stud Earrings - 8mm - G0143', '9ct-gold-two-colour-open-heart-stud-earrings-8mm-g0143', '', 'https://cdn.shopify.com/s/files/1/0367/2447/3901/products/G0143_L_1.jpg?v=1584595423', '', '', '', '', '', '', 'apptestsuff.myshopify.com'),
(131, '4774734397485', '9ct White Gold Diamond Half Eternity Ring - 1/4ct - D7174-S', '9ct-white-gold-diamond-half-eternity-ring-1-4ct-d7174-s', '', 'https://cdn.shopify.com/s/files/1/0367/2447/3901/products/D7174_L_1.jpg?v=1584595422', '', '', '', '', '', '', 'apptestsuff.myshopify.com'),
(132, '4774735380525', '9ct White Gold Diamond Open Crossover Ring - 10pts - D7010-A', '9ct-white-gold-diamond-open-crossover-ring-10pts-d7010-a', '', 'https://cdn.shopify.com/s/files/1/0367/2447/3901/products/D7010_L_1.jpg?v=1584595437', '', '', '', '', '', '', 'apptestsuff.myshopify.com'),
(133, '4774735118381', 'Platinum Diamond Solitaire Ring - 20pts - AGI Certificated - D0813-K', 'platinum-diamond-solitaire-ring-20pts-agi-certificated-d0813-k', '', 'https://cdn.shopify.com/s/files/1/0367/2447/3901/products/D0813_L_1.jpg?v=1584595433', '', '', '', '', '', '', 'apptestsuff.myshopify.com'),
(134, '4774735020077', 'Silver Celtic Ring - F5532-P', 'silver-celtic-ring-f5532-p', '', 'https://cdn.shopify.com/s/files/1/0367/2447/3901/products/F5532_L_1.jpg?v=1584595432', '', '', '', '', '', '', 'apptestsuff.myshopify.com'),
(135, '4774735609901', 'Silver Cubic Zirconia Double Heart Necklace - F3501', 'silver-cubic-zirconia-double-heart-necklace-f3501', '', 'https://cdn.shopify.com/s/files/1/0367/2447/3901/products/F3501_L_1.jpg?v=1584595440', '', '', '', '', '', '', 'apptestsuff.myshopify.com'),
(136, '4774734266413', 'Silver Cubic Zirconia Floating Heart Pendant And Chain - F3458', 'silver-cubic-zirconia-floating-heart-pendant-and-chain-f3458', '', 'https://cdn.shopify.com/s/files/1/0367/2447/3901/products/F3458_L_1.jpg?v=1584595421', '', '', '', '', '', '', 'apptestsuff.myshopify.com'),
(137, '4774735249453', 'Silver Cubic Zirconia Knot Stud Earrings - 10mm - F0463', 'silver-cubic-zirconia-knot-stud-earrings-10mm-f0463', '', 'https://cdn.shopify.com/s/files/1/0367/2447/3901/products/F0463_L_1.jpg?v=1584595435', '', '', '', '', '', '', 'apptestsuff.myshopify.com'),
(138, '4774735478829', 'Silver Cubic Zirconia Two Hearts Necklace - F3497', 'silver-cubic-zirconia-two-hearts-necklace-f3497', '', 'https://cdn.shopify.com/s/files/1/0367/2447/3901/products/F3497_L_1.jpg?v=1584595438', '', '', '', '', '', '', 'apptestsuff.myshopify.com'),
(139, '4774734626861', 'Silver Diamond Cut Hoop Earrings - 25mm - F1346', 'silver-diamond-cut-hoop-earrings-25mm-f1346', '', 'https://cdn.shopify.com/s/files/1/0367/2447/3901/products/F1346_L_1.jpg?v=1584595426', '', '', '', '', '', '', 'apptestsuff.myshopify.com'),
(140, '4774734889005', 'Silver Double Strand Crossover Ring - F5471-R', 'silver-double-strand-crossover-ring-f5471-r', '', 'https://cdn.shopify.com/s/files/1/0367/2447/3901/products/F5471_L_1.jpg?v=1584595430', '', '', '', '', '', '', 'apptestsuff.myshopify.com'),
(141, '4774735151149', 'Silver Gecko Stud Earrings - 7mm - F0108', 'silver-gecko-stud-earrings-7mm-f0108', '', 'https://cdn.shopify.com/s/files/1/0367/2447/3901/products/F0108_L_1.jpg?v=1584595434', '', '', '', '', '', '', 'apptestsuff.myshopify.com'),
(142, '4774734168109', 'Silver Light Blue Resin And Crystal Flower Earrings - 8mm - F0464', 'silver-light-blue-resin-and-crystal-flower-earrings-8mm-f0464', '', 'https://cdn.shopify.com/s/files/1/0367/2447/3901/products/F0464_L_1.jpg?v=1584595419', '', '', '', '', '', '', 'apptestsuff.myshopify.com'),
(143, '4774734954541', 'Silver Patterned Band Ring - 4mm - F5491-Q', 'silver-patterned-band-ring-4mm-f5491-q', '', 'https://cdn.shopify.com/s/files/1/0367/2447/3901/products/F5491_L_1.jpg?v=1584595431', '', '', '', '', '', '', 'apptestsuff.myshopify.com'),
(144, '4774734823469', 'Silver Plaited Revolving Band Ring - 8mm - F4815-X', 'silver-plaited-revolving-band-ring-8mm-f4815-x', '', 'https://cdn.shopify.com/s/files/1/0367/2447/3901/products/F4815_L_1.jpg?v=1584595428', '', '', '', '', '', '', 'apptestsuff.myshopify.com'),
(145, '4774734659629', 'Silver Prince Of Wales Feathers Ring - F4953-W', 'silver-prince-of-wales-feathers-ring-f4953-w', '', 'https://cdn.shopify.com/s/files/1/0367/2447/3901/products/F4953_L_1.jpg?v=1584595427', '', '', '', '', '', '', 'apptestsuff.myshopify.com'),
(146, '4774736527405', '9ct Gold Two Colour Black Sapphire And Diamond Heart Stud Earrings - 6mm - G0230', '9ct-gold-two-colour-black-sapphire-and-diamond-heart-stud-earrings-6mm-g0230', '', 'https://cdn.shopify.com/s/files/1/0367/2447/3901/products/G0230_L_1.jpg?v=1584595457', '', '', '', '', '', '', 'apptestsuff.myshopify.com'),
(147, '4774737346605', 'D For Diamond Silver Diamond Set Heart Expandable Baby Bangle - D8511', 'd-for-diamond-silver-diamond-set-heart-expandable-baby-bangle-d8511', '', 'https://cdn.shopify.com/s/files/1/0367/2447/3901/products/D8511_L_1.jpg?v=1584595469', '', '', '', '', '', '', 'apptestsuff.myshopify.com'),
(148, '4774737903661', 'Silver Crystal Cross Stud Earrings - 15mm drop - F1151', 'silver-crystal-cross-stud-earrings-15mm-drop-f1151', '', 'https://cdn.shopify.com/s/files/1/0367/2447/3901/products/F1151_L_1.jpg?v=1584595477', '', '', '', '', '', '', 'apptestsuff.myshopify.com'),
(149, '4774738001965', 'Silver Cubic Zirconia Cluster Ring - F5970-N', 'silver-cubic-zirconia-cluster-ring-f5970-n', '', 'https://cdn.shopify.com/s/files/1/0367/2447/3901/products/F5970_L_1_b12b7133-1166-455b-9636-68cfc532f4f0.jpg?v=1584595479', '', '', '', '', '', '', 'apptestsuff.myshopify.com'),
(150, '4774738100269', 'Silver Cubic Zirconia Cluster Ring - F5970-R', 'silver-cubic-zirconia-cluster-ring-f5970-r', '', 'https://cdn.shopify.com/s/files/1/0367/2447/3901/products/F5970_L_1_6a04c834-1800-4e19-864f-b0c817574c52.jpg?v=1584595480', '', '', '', '', '', '', 'apptestsuff.myshopify.com'),
(151, '4774736625709', 'Silver Cubic Zirconia Crossover Ring - F5962-L', 'silver-cubic-zirconia-crossover-ring-f5962-l', '', 'https://cdn.shopify.com/s/files/1/0367/2447/3901/products/F5962_L_1.jpg?v=1584595458', '', '', '', '', '', '', 'apptestsuff.myshopify.com'),
(152, '4774736756781', 'Silver Cubic Zirconia Crossover Ring - F5962-M', 'silver-cubic-zirconia-crossover-ring-f5962-m', '', 'https://cdn.shopify.com/s/files/1/0367/2447/3901/products/F5962_L_1_ea213597-d274-4f61-ac0b-402fe664563e.jpg?v=1584595460', '', '', '', '', '', '', 'apptestsuff.myshopify.com'),
(153, '4774736855085', 'Silver Cubic Zirconia Crossover Ring - F5962-N', 'silver-cubic-zirconia-crossover-ring-f5962-n', '', 'https://cdn.shopify.com/s/files/1/0367/2447/3901/products/F5962_L_1_dcd88101-4a77-4de1-be07-29641cef5695.jpg?v=1584595462', '', '', '', '', '', '', 'apptestsuff.myshopify.com'),
(154, '4774737018925', 'Silver Cubic Zirconia Crossover Ring - F5962-O', 'silver-cubic-zirconia-crossover-ring-f5962-o', '', 'https://cdn.shopify.com/s/files/1/0367/2447/3901/products/F5962_L_1_c93295f1-934a-4b59-a115-7e77cf8d8249.jpg?v=1584595464', '', '', '', '', '', '', 'apptestsuff.myshopify.com'),
(155, '4774737149997', 'Silver Cubic Zirconia Crossover Ring - F5962-P', 'silver-cubic-zirconia-crossover-ring-f5962-p', '', 'https://cdn.shopify.com/s/files/1/0367/2447/3901/products/F5962_L_1_816da653-cae0-4ca7-9bd8-404f4279f692.jpg?v=1584595465', '', '', '', '', '', '', 'apptestsuff.myshopify.com'),
(156, '4774736330797', 'Silver Cubic Zirconia Leaf Drop Earrings - 20mm drop - F1102', 'silver-cubic-zirconia-leaf-drop-earrings-20mm-drop-f1102', '', 'https://cdn.shopify.com/s/files/1/0367/2447/3901/products/F1102_L_1.jpg?v=1584595454', '', '', '', '', '', '', 'apptestsuff.myshopify.com'),
(157, '4774736396333', 'Silver Cubic Zirconia Tendril Drop Earrings - 25mm drop - F1106', 'silver-cubic-zirconia-tendril-drop-earrings-25mm-drop-f1106', '', 'https://cdn.shopify.com/s/files/1/0367/2447/3901/products/F1106_L_1.jpg?v=1584595455', '', '', '', '', '', '', 'apptestsuff.myshopify.com'),
(158, '4774736199725', 'Silver Cubic Zirconia Trilogy Pendant And Chain - F3439', 'silver-cubic-zirconia-trilogy-pendant-and-chain-f3439', '', 'https://cdn.shopify.com/s/files/1/0367/2447/3901/products/F3439_L_1.jpg?v=1584595452', '', '', '', '', '', '', 'apptestsuff.myshopify.com'),
(199, '4430287700019', 'Silver Pink And Blue Seahorse Earrings - 10mm - F0409', 'silver-pink-and-blue-seahorse-earrings-10mm-f0409', '', 'https://cdn.shopify.com/s/files/1/0096/8445/1379/products/F0409_L_1.jpg?v=1579669789', 'Craft your note!', '150', '', '', '', '', 'suffes-dev.myshopify.com'),
(200, '4430288289843', 'Silver Plaited Revolving Band Ring - 8mm - F4815-X', 'silver-plaited-revolving-band-ring-8mm-f4815-x', '', 'https://cdn.shopify.com/s/files/1/0096/8445/1379/products/F4815_L_1.jpg?v=1579669807', 'Craft your note!', '150', '', '', '', '', 'suffes-dev.myshopify.com'),
(201, '4430288191539', 'Silver Prince Of Wales Feathers Ring - F4953-W', 'silver-prince-of-wales-feathers-ring-f4953-w', '', 'https://cdn.shopify.com/s/files/1/0096/8445/1379/products/F4953_L_1.jpg?v=1579669805', 'Craft your note!', '150', '', '', '', '', 'suffes-dev.myshopify.com'),
(202, '4657122148483', '18ct White Gold Diamond Solitaire Ring - 60pts - Certificated - D2306-O', '18ct-white-gold-diamond-solitaire-ring-60pts-certificated-d2306-o', '', 'https://cdn.shopify.com/s/files/1/0366/8675/8019/products/D2306_L_1.jpg?v=1584607407', 'Craft your note!', '150', '', '', '', '', 'suffescomwe.myshopify.com'),
(203, '4657122279555', '9ct Gold Amethyst Teardrop Stud Earrings - 7mm - G0416', '9ct-gold-amethyst-teardrop-stud-earrings-7mm-g0416', 'tdzdf dfsfdt dfdfgdfgd', 'https://cdn.shopify.com/s/files/1/0366/8675/8019/products/G0416_L_1.jpg?v=1584607411', 'Craft your note!', '150', 'Yes', 'Yes', 'Yes', '', 'suffescomwe.myshopify.com'),
(204, '4657121591427', '9ct Gold Diamond Heart Necklace - 5pts - D5608', '9ct-gold-diamond-heart-necklace-5pts-d5608', 'dfg dfg ', 'https://cdn.shopify.com/s/files/1/0366/8675/8019/products/D5608_L_1.jpg?v=1584607391', 'Craft your note!', '150', 'Yes', 'Yes', 'Yes', '', 'suffescomwe.myshopify.com'),
(205, '4657122410627', '9ct Gold Facetted Flower Earrings - G0220', '9ct-gold-facetted-flower-earrings-g0220', 'gd fgfd', 'https://cdn.shopify.com/s/files/1/0366/8675/8019/products/G0220_L_1.jpg?v=1584607417', 'Craft your note!', '150', 'Yes', 'Yes', 'Yes', '', 'suffescomwe.myshopify.com'),
(206, '4657122476163', '9ct Gold Star Earrings - 7mm - G0221', '9ct-gold-star-earrings-7mm-g0221', '', 'https://cdn.shopify.com/s/files/1/0366/8675/8019/products/G0221_L_1.jpg?v=1584607418', 'Craft your note!', '150', '', '', '', '', 'suffescomwe.myshopify.com'),
(207, '4657122672771', '9ct Gold Two Colour Black Sapphire And Diamond Heart Stud Earrings - 6mm - G0230', '9ct-gold-two-colour-black-sapphire-and-diamond-heart-stud-earrings-6mm-g0230', '', 'https://cdn.shopify.com/s/files/1/0366/8675/8019/products/G0230_L_1.jpg?v=1584607424', 'Craft your note!', '150', '', '', '', '', 'suffescomwe.myshopify.com'),
(208, '4657122345091', '9ct Gold Two Colour Loop Stud Earrings - 10mm - G0120', '9ct-gold-two-colour-loop-stud-earrings-10mm-g0120', '', 'https://cdn.shopify.com/s/files/1/0366/8675/8019/products/G0120_L_1.jpg?v=1584607415', 'Craft your note!', '150', '', '', '', '', 'suffescomwe.myshopify.com'),
(209, '4657121558659', '9ct Gold Two Colour Open Heart Stud Earrings - 8mm - G0143', '9ct-gold-two-colour-open-heart-stud-earrings-8mm-g0143', '', 'https://cdn.shopify.com/s/files/1/0366/8675/8019/products/G0143_L_1.jpg?v=1584607389', 'Craft your note!', '150', '', '', '', '', 'suffescomwe.myshopify.com'),
(210, '4657121165443', '9ct Two Colour Gold Blue Topaz And Diamond Stud Earrings - 13mm - G0684', '9ct-two-colour-gold-blue-topaz-and-diamond-stud-earrings-13mm-g0684', '', 'https://cdn.shopify.com/s/files/1/0366/8675/8019/products/G0684_L_1.jpg?v=1584607381', 'Craft your note!', '150', '', '', '', '', 'suffescomwe.myshopify.com'),
(211, '4657121230979', '9ct White Gold Ball Stud Earrings - 5mm - G0692', '9ct-white-gold-ball-stud-earrings-5mm-g0692', '', 'https://cdn.shopify.com/s/files/1/0366/8675/8019/products/G0692_L_1.jpg?v=1584607382', 'Craft your note!', '150', '', '', '', '', 'suffescomwe.myshopify.com'),
(212, '4657121525891', '9ct White Gold Diamond Half Eternity Ring - 1/4ct - D7174-S', '9ct-white-gold-diamond-half-eternity-ring-1-4ct-d7174-s', '', 'https://cdn.shopify.com/s/files/1/0366/8675/8019/products/D7174_L_1.jpg?v=1584607388', 'Craft your note!', '150', '', '', '', '', 'suffescomwe.myshopify.com'),
(213, '4657122050179', '9ct White Gold Diamond Open Crossover Ring - 10pts - D7010-A', '9ct-white-gold-diamond-open-crossover-ring-10pts-d7010-a', '', 'https://cdn.shopify.com/s/files/1/0366/8675/8019/products/D7010_L_1.jpg?v=1584607404', 'Craft your note!', '150', '', '', '', '', 'suffescomwe.myshopify.com'),
(214, '4657123098755', 'D For Diamond Silver Diamond Set Heart Expandable Baby Bangle - D8511', 'd-for-diamond-silver-diamond-set-heart-expandable-baby-bangle-d8511', '', 'https://cdn.shopify.com/s/files/1/0366/8675/8019/products/D8511_L_1.jpg?v=1584607434', 'Craft your note!', '150', '', '', '', '', 'suffescomwe.myshopify.com'),
(215, '4657121886339', 'Platinum Diamond Solitaire Ring - 20pts - AGI Certificated - D0813-K', 'platinum-diamond-solitaire-ring-20pts-agi-certificated-d0813-k', '', 'https://cdn.shopify.com/s/files/1/0366/8675/8019/products/D0813_L_1.jpg?v=1584607400', 'Craft your note!', '150', '', '', '', '', 'suffescomwe.myshopify.com'),
(216, '4657121820803', 'Silver Celtic Ring - F5532-P', 'silver-celtic-ring-f5532-p', '', 'https://cdn.shopify.com/s/files/1/0366/8675/8019/products/F5532_L_1.jpg?v=1584607399', 'Craft your note!', '150', '', '', '', '', 'suffescomwe.myshopify.com'),
(217, '4657123459203', 'Silver Crystal Cross Stud Earrings - 15mm drop - F1151', 'silver-crystal-cross-stud-earrings-15mm-drop-f1151', '', 'https://cdn.shopify.com/s/files/1/0366/8675/8019/products/F1151_L_1.jpg?v=1584607443', 'Craft your note!', '150', '', '', '', '', 'suffescomwe.myshopify.com'),
(218, '4657123557507', 'Silver Cubic Zirconia Cluster Ring - F5970-N', 'silver-cubic-zirconia-cluster-ring-f5970-n', '', 'https://cdn.shopify.com/s/files/1/0366/8675/8019/products/F5970_L_1_b12b7133-1166-455b-9636-68cfc532f4f0.jpg?v=1584607445', 'Craft your note!', '150', '', '', '', '', 'suffescomwe.myshopify.com'),
(219, '4657123623043', 'Silver Cubic Zirconia Cluster Ring - F5970-R', 'silver-cubic-zirconia-cluster-ring-f5970-r', '', 'https://cdn.shopify.com/s/files/1/0366/8675/8019/products/F5970_L_1_6a04c834-1800-4e19-864f-b0c817574c52.jpg?v=1584607446', 'Craft your note!', '150', '', '', '', '', 'suffescomwe.myshopify.com'),
(220, '4657122705539', 'Silver Cubic Zirconia Crossover Ring - F5962-L', 'silver-cubic-zirconia-crossover-ring-f5962-l', '', 'https://cdn.shopify.com/s/files/1/0366/8675/8019/products/F5962_L_1.jpg?v=1584607425', 'Craft your note!', '150', '', '', '', '', 'suffescomwe.myshopify.com'),
(221, '4657122771075', 'Silver Cubic Zirconia Crossover Ring - F5962-M', 'silver-cubic-zirconia-crossover-ring-f5962-m', '', 'https://cdn.shopify.com/s/files/1/0366/8675/8019/products/F5962_L_1_ea213597-d274-4f61-ac0b-402fe664563e.jpg?v=1584607427', 'Craft your note!', '150', '', '', '', '', 'suffescomwe.myshopify.com'),
(222, '4657122902147', 'Silver Cubic Zirconia Crossover Ring - F5962-N', 'silver-cubic-zirconia-crossover-ring-f5962-n', '', 'https://cdn.shopify.com/s/files/1/0366/8675/8019/products/F5962_L_1_dcd88101-4a77-4de1-be07-29641cef5695.jpg?v=1584607428', 'Craft your note!', '150', '', '', '', '', 'suffescomwe.myshopify.com'),
(223, '4657122934915', 'Silver Cubic Zirconia Crossover Ring - F5962-O', 'silver-cubic-zirconia-crossover-ring-f5962-o', '', 'https://cdn.shopify.com/s/files/1/0366/8675/8019/products/F5962_L_1_c93295f1-934a-4b59-a115-7e77cf8d8249.jpg?v=1584607430', 'Craft your note!', '150', '', '', '', '', 'suffescomwe.myshopify.com'),
(224, '4657122967683', 'Silver Cubic Zirconia Crossover Ring - F5962-P', 'silver-cubic-zirconia-crossover-ring-f5962-p', '', 'https://cdn.shopify.com/s/files/1/0366/8675/8019/products/F5962_L_1_816da653-cae0-4ca7-9bd8-404f4279f692.jpg?v=1584607431', 'Craft your note!', '150', '', '', '', '', 'suffescomwe.myshopify.com'),
(225, '4657122181251', 'Silver Cubic Zirconia Double Heart Necklace - F3501', 'silver-cubic-zirconia-double-heart-necklace-f3501', '', 'https://cdn.shopify.com/s/files/1/0366/8675/8019/products/F3501_L_1.jpg?v=1584607409', 'Craft your note!', '150', '', '', '', '', 'suffescomwe.myshopify.com'),
(226, '4657121493123', 'Silver Cubic Zirconia Floating Heart Pendant And Chain - F3458', 'silver-cubic-zirconia-floating-heart-pendant-and-chain-f3458', '', 'https://cdn.shopify.com/s/files/1/0366/8675/8019/products/F3458_L_1.jpg?v=1584607387', 'Craft your note!', '150', '', '', '', '', 'suffescomwe.myshopify.com'),
(227, '4657122017411', 'Silver Cubic Zirconia Knot Stud Earrings - 10mm - F0463', 'silver-cubic-zirconia-knot-stud-earrings-10mm-f0463', '', 'https://cdn.shopify.com/s/files/1/0366/8675/8019/products/F0463_L_1.jpg?v=1584607403', 'Craft your note!', '150', '', '', '', '', 'suffescomwe.myshopify.com'),
(228, '4657122574467', 'Silver Cubic Zirconia Leaf Drop Earrings - 20mm drop - F1102', 'silver-cubic-zirconia-leaf-drop-earrings-20mm-drop-f1102', '', 'https://cdn.shopify.com/s/files/1/0366/8675/8019/products/F1102_L_1.jpg?v=1584607421', 'Craft your note!', '150', '', '', '', '', 'suffescomwe.myshopify.com'),
(229, '4657122640003', 'Silver Cubic Zirconia Tendril Drop Earrings - 25mm drop - F1106', 'silver-cubic-zirconia-tendril-drop-earrings-25mm-drop-f1106', '', 'https://cdn.shopify.com/s/files/1/0366/8675/8019/products/F1106_L_1.jpg?v=1584607422', 'Craft your note!', '150', '', '', '', '', 'suffescomwe.myshopify.com'),
(230, '4657122541699', 'Silver Cubic Zirconia Trilogy Pendant And Chain - F3439', 'silver-cubic-zirconia-trilogy-pendant-and-chain-f3439', '', 'https://cdn.shopify.com/s/files/1/0366/8675/8019/products/F3439_L_1.jpg?v=1584607419', 'Craft your note!', '150', '', '', '', '', 'suffescomwe.myshopify.com'),
(231, '4657122115715', 'Silver Cubic Zirconia Two Hearts Necklace - F3497', 'silver-cubic-zirconia-two-hearts-necklace-f3497', '', 'https://cdn.shopify.com/s/files/1/0366/8675/8019/products/F3497_L_1.jpg?v=1584607406', 'Craft your note!', '150', '', '', '', '', 'suffescomwe.myshopify.com'),
(232, '4657121624195', 'Silver Diamond Cut Hoop Earrings - 25mm - F1346', 'silver-diamond-cut-hoop-earrings-25mm-f1346', '', 'https://cdn.shopify.com/s/files/1/0366/8675/8019/products/F1346_L_1.jpg?v=1584607392', 'Craft your note!', '150', '', '', '', '', 'suffescomwe.myshopify.com'),
(233, '4657121755267', 'Silver Double Strand Crossover Ring - F5471-R', 'silver-double-strand-crossover-ring-f5471-r', '', 'https://cdn.shopify.com/s/files/1/0366/8675/8019/products/F5471_L_1.jpg?v=1584607396', 'Craft your note!', '150', '', '', '', '', 'suffescomwe.myshopify.com'),
(234, '4657121951875', 'Silver Gecko Stud Earrings - 7mm - F0108', 'silver-gecko-stud-earrings-7mm-f0108', '', 'https://cdn.shopify.com/s/files/1/0366/8675/8019/products/F0108_L_1.jpg?v=1584607402', 'Craft your note!', '150', '', '', '', '', 'suffescomwe.myshopify.com'),
(235, '4657121394819', 'Silver Light Blue Resin And Crystal Flower Earrings - 8mm - F0464', 'silver-light-blue-resin-and-crystal-flower-earrings-8mm-f0464', '', 'https://cdn.shopify.com/s/files/1/0366/8675/8019/products/F0464_L_1.jpg?v=1584607385', 'Craft your note!', '150', '', '', '', '', 'suffescomwe.myshopify.com'),
(236, '4657121788035', 'Silver Patterned Band Ring - 4mm - F5491-Q', 'silver-patterned-band-ring-4mm-f5491-q', '', 'https://cdn.shopify.com/s/files/1/0366/8675/8019/products/F5491_L_1.jpg?v=1584607398', 'Craft your note!', '150', '', '', '', '', 'suffescomwe.myshopify.com'),
(237, '4657121296515', 'Silver Pink And Blue Seahorse Earrings - 10mm - F0409', 'silver-pink-and-blue-seahorse-earrings-10mm-f0409', '', 'https://cdn.shopify.com/s/files/1/0366/8675/8019/products/F0409_L_1.jpg?v=1584607384', 'Craft your note!', '150', '', '', '', '', 'suffescomwe.myshopify.com'),
(238, '4657121689731', 'Silver Plaited Revolving Band Ring - 8mm - F4815-X', 'silver-plaited-revolving-band-ring-8mm-f4815-x', '', 'https://cdn.shopify.com/s/files/1/0366/8675/8019/products/F4815_L_1.jpg?v=1584607395', 'Craft your note!', '150', '', '', '', '', 'suffescomwe.myshopify.com'),
(239, '4657121656963', 'Silver Prince Of Wales Feathers Ring - F4953-W', 'silver-prince-of-wales-feathers-ring-f4953-w', '', 'https://cdn.shopify.com/s/files/1/0366/8675/8019/products/F4953_L_1.jpg?v=1584607394', 'Craft your note!', '150', '', '', '', '', 'suffescomwe.myshopify.com'),
(240, '4464054304814', 'Pereira Skin Health', 'pereira-skin-health', '', 'https://cdn.shopify.com/s/files/1/0248/2880/5166/products/1.png?v=1584097486', 'Craft your note!', '150', '', '', '', '', 'balensiskincare.myshopify.com'),
(241, '4464055484462', 'Pereira Skin Health', 'pereira-skin-health-1', '', 'https://cdn.shopify.com/s/files/1/0248/2880/5166/products/2.png?v=1584097519', 'Craft your note!', '150', '', '', '', '', 'balensiskincare.myshopify.com'),
(242, '4464055681070', 'Pereira Skin Health', 'pereira-skin-health-2', '', 'https://cdn.shopify.com/s/files/1/0248/2880/5166/products/3.png?v=1584097540', 'Craft your note!', '150', '', '', '', '', 'balensiskincare.myshopify.com'),
(243, '4465873354798', 'Pereira Skin Health', 'pereira-skin-health-3', '', 'https://cdn.shopify.com/s/files/1/0248/2880/5166/products/Pereira-Skin-Health-1.png?v=1584435340', 'Craft your note!', '150', '', '', '', '', 'balensiskincare.myshopify.com'),
(244, '4465873616942', 'Pereira Skin Health', 'pereira-skin-health-4', '', 'https://cdn.shopify.com/s/files/1/0248/2880/5166/products/Pereira-Skin-Health-3.png?v=1584435385', 'Craft your note!', '150', '', '', '', '', 'balensiskincare.myshopify.com'),
(245, '4465874206766', 'Pereira Skin Health', 'pereira-skin-health-5', '', 'https://cdn.shopify.com/s/files/1/0248/2880/5166/products/Pereira-Skin-Health-3_ba19ec54-881a-4123-8542-cc60c190c466.png?v=1584435394', 'Craft your note!', '150', '', '', '', '', 'balensiskincare.myshopify.com'),
(246, '4465874501678', 'Pereira Skin Health', 'pereira-skin-health-6', '', 'https://cdn.shopify.com/s/files/1/0248/2880/5166/products/Pereira-Skin-Health-1_6e9d263a-d473-458f-b52c-9ab79c95aae1.png?v=1584435755', 'Craft your note!', '150', '', '', '', '', 'balensiskincare.myshopify.com'),
(247, '4465875648558', 'Pereira Skin Health', 'pereira-skin-health-7', '', 'https://cdn.shopify.com/s/files/1/0248/2880/5166/products/Pereira-Skin-Health_c05e0b2c-31fd-4419-b432-311c4434b962.png?v=1584435613', 'Craft your note!', '150', '', '', '', '', 'balensiskincare.myshopify.com'),
(248, '4465872732206', 'Skin Caviar Luxe Cream', 'skin-caviar-luxe-cream', '', 'https://cdn.shopify.com/s/files/1/0248/2880/5166/products/Pereira-Skin-Health.png?v=1584435255', 'Craft your note!', '150', '', '', '', '', 'balensiskincare.myshopify.com');*/

--
-- Indexes for dumped tables
--

--
-- Indexes for table `installs`
--
ALTER TABLE `installs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `popup_detail`
--
ALTER TABLE `popup_detail`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_detail`
--
ALTER TABLE `product_detail`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `installs`
--
ALTER TABLE `installs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `popup_detail`
--
ALTER TABLE `popup_detail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `product_detail`
--
ALTER TABLE `product_detail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=249;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

-- Password setting for admin console. Replace password and shopify store url


CREATE TABLE `private_pass` (
  `id` int(11) NOT NULL,
  `app_password` varchar(255) NOT NULL,
  `store_name` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

INSERT INTO `private_pass` (`id`, `app_password`, `store_name`) VALUES
(1, 'myPassword', 'mystore.myshopify.com');
