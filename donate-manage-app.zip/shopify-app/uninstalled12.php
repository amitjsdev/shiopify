<?php
error_reporting(E_ALL & ~E_NOTICE);
require 'vendor/autoload.php';
use GuzzleHttp\Client;
$dotenv = new Dotenv\Dotenv(__DIR__);
$dotenv->load();
$db = new Mysqli(getenv('MYSQL_HOST'), getenv('MYSQL_USER'), getenv('MYSQL_PASS'), getenv('MYSQL_DB'));

$data = file_get_contents('php://input');
$get_domain = json_decode($data, true);
$serverUrl = "https://shopifyapp.bestwebdevs.com";
/* $store = $_POST['X-Shopify-Shop-Domain']; */
$store = $get_domain['domain'];

$select = $db->query("SELECT access_token FROM installs WHERE store = '$store'");

$user = $select->fetch_object();

$access_token = $user->access_token;

$client = new Client();

$loader = new Twig_Loader_Filesystem('templates');

$twig = new Twig_Environment($loader, [

   'cache' => 'cache',

   'debug' => true

]);

$json_decode = json_encode($_POST);

$json_decode2 = json_encode($_GET);

$select = $db->query("SELECT access_token,id FROM installs WHERE store = '$store'");

$user = $select->fetch_object();

$access_token = $user->access_token;

$store_access_id = $user->id;

$del= $db->query("DELETE FROM store_data WHERE store='$store'");

$delStore= $db->query("DELETE FROM installs WHERE store='$store'");

   
    $response_webhook  = $client->request(
		'GET', 
		"https://{$store}/admin/script_tags.json",
		[   
			'query' => [
				'fields' => 'id,src',
				'access_token' => $access_token
			]
		]
	);

	$get_res_webhook  = json_decode($response_webhook ->getBody()->getContents(), true);
	$res_title_webhook = array();
 	foreach($get_res_webhook['script_tags'] as $r){
		$script_id = $r['id'];
		$res_title_webhook[$script_id] = $r['src'];
 	}
		foreach($res_title_webhook as $key=>$val){
			
			if ("https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js" == $val){
				
					$response_webhook  = $client->request(
						'DELETE', 
						"https://{$store}/admin/script_tags/{$key}.json",
						[   
							'query' => [
								'fields' => 'id,src',
								'access_token' => $access_token
							]
						]
					);
			
				$get_res_webhook  = json_decode($response_webhook ->getBody()->getContents(), true);
			}
			
			if ($serverUrl."/gift-handwritten/note_field.js" == $val){
				
					$response_webhook  = $client->request(
						'DELETE', 
						"https://{$store}/admin/script_tags/{$key}.json",
						[   
							'query' => [
								'fields' => 'id,src',
								'access_token' => $access_token
							]
						]
					);
			
				$get_res_webhook  = json_decode($response_webhook ->getBody()->getContents(), true);
			}
		}	