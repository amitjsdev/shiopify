<?php 

//ini_set('display_errors', 1);

header("Access-Control-Allow-Origin: *");

ini_set('error_reporting', E_ALL);
       require 'vendor/autoload.php';
	
	use Carbon\Carbon;
	use GuzzleHttp\Client;
	
	$dotenv = new Dotenv\Dotenv(__DIR__);
	$dotenv->load();
	$client = new Client();
	  $store =$_GET['shop'];
	  //$store = "suffes-dev.myshopify.com";
	$theme_id = "";
	$access_token="";
	
	$db = new Mysqli(getenv('MYSQL_HOST'), getenv('MYSQL_USER'), getenv('MYSQL_PASS'), getenv('MYSQL_DB')); 
	

 $mainId = $_POST["MainId"];
 
 $pro_id = $_POST["pro_id"];

			if($mainId != ""){
					$results = $db->query("SELECT * FROM product_detail where storeName = '$store' AND id ='$mainId'");	
					$arr=array();
					if($results->num_rows != 0){
						 $row = mysqli_fetch_assoc($results);
						$prevProductArray = json_decode($row["exclusion_product"],true);
	
					 if(($key = array_search($pro_id,$prevProductArray)) !== false) {
						 
						   unset($prevProductArray[$key]);
					  }    
					  
								if(count($prevProductArray) > 0){
									
								//	$finalArray=array_merge($prevProductArray,array($pro_id));
									  $arr_ids = json_encode(array_unique($prevProductArray));
									 $update_sql="UPDATE `product_detail` set exclusion_product='$arr_ids' where  id='$mainId'";
									$reslt=mysqli_query($db,$update_sql);	
										if($reslt){
											$results2 = $db->query("SELECT * FROM product_detail where storeName = '$store' AND id ='$mainId'");
											$row2 = mysqli_fetch_assoc($results2); 
											$exclusion_product_data = json_decode($row2["exclusion_product"],true);
											//print_r($exclusion_product);
											foreach($exclusion_product_data as $value){
												$results3 = $db->query("SELECT * FROM product_detail where storeName = '$store' AND product_id ='$value'");
													if($results3->num_rows != 0){
															$row3 = mysqli_fetch_assoc($results3); 
													echo '<span class="xclusionPrdcts" data-mainId="'.$mainId.'" data-id="'.$value.'">'.$row3["product_title"].'<span class="closeBtn" data-mainId="'.$mainId.'" data-close="'.$value.'">x</span></span>';
												}
												
											}
											
										}
								}else{
								
									 $update_sql="UPDATE `product_detail` set exclusion_product='' where  id='$mainId'";
									$reslt=mysqli_query($db,$update_sql);	
										if($reslt){
											echo 0;
										}
								}
							
								
					}else{
						echo 0;
					}
			}else{
				echo 0;
			}
							?>