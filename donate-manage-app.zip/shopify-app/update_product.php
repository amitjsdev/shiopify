	<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: *');
header('Access-Control-Allow-Headers: *');

//ini_set('error_reporting', E_ALL);
       require 'vendor/autoload.php';
	
	use Carbon\Carbon;
	use GuzzleHttp\Client;
	
	$dotenv = new Dotenv\Dotenv(__DIR__);
	$dotenv->load();
	$client = new Client();

		$db = new Mysqli(getenv('MYSQL_HOST'), getenv('MYSQL_USER'), getenv('MYSQL_PASS'), getenv('MYSQL_DB')); 
if($_POST['productId']){
		$productId=$_POST['productId'];
		$labelText=$_POST['labelText'];
		$characterLimit=$_POST['characterLimit'];
		$showTextNote=$_POST['showTextNote'];
		$fieldRequired=$_POST['fieldRequired'];
		$showPopup=$_POST['showPopup'];
		$description=$_POST['description'];
			$results = $db->query("SELECT * FROM product_detail where id = '$productId'");	
			if($results){  
				$update_sql="UPDATE `product_detail` set label_text_area='$labelText', meals_count='$characterLimit', show_text_area='$showTextNote', show_on_popup='$showPopup', field_required='$fieldRequired', product_description='$description' where  id='$productId'";
				$reslt=mysqli_query($db,$update_sql);	
				if($reslt){
				echo "Updated";
				}else{
					echo "Not Updated";
				}
				 
			}
}
			?>
			