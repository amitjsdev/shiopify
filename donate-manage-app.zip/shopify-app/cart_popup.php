<?php

 header('Access-Control-Allow-Origin: *'); 

		ini_set('error_reporting', E_ALL);
		require 'vendor/autoload.php';
		use Carbon\Carbon;
		use GuzzleHttp\Client;
		$dotenv = new Dotenv\Dotenv(__DIR__);
		$dotenv->load();
		$client = new Client();
		$db = new Mysqli(getenv('MYSQL_HOST'), getenv('MYSQL_USER'), getenv('MYSQL_PASS'), getenv('MYSQL_DB'));
		
	$store = $_GET['shop'];
		
 if($store){
			$arr = array();
			$results = $db->query("SELECT * FROM popup_detail where store_name ='$store'");	
				 $row = mysqli_fetch_assoc($results); 
			
				 
				 $arr["popupHeading"]=$row["popupHeading"];
				 $arr["popupContent"]=$row["popupContent"];
				 $arr["disclaimerText"]=$row["disclaimerText"];
				 if($row["nothanks"]){
					 $arr["nothanks"]=$row["nothanks"];
				 }else{
					 $arr["nothanks"]="";
				 }
				 
				 
			echo json_encode($arr);
 }