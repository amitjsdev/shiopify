<?php

 header('Access-Control-Allow-Origin: *'); 

		ini_set('error_reporting', E_ALL);
		require 'vendor/autoload.php';
		use Carbon\Carbon;
		use GuzzleHttp\Client;
		$dotenv = new Dotenv\Dotenv(__DIR__);
		$dotenv->load();
		$client = new Client();
		$db = new Mysqli(getenv('MYSQL_HOST'), getenv('MYSQL_USER'), getenv('MYSQL_PASS'), getenv('MYSQL_DB'));
		  
		

		$store = $_GET['shop'];
		$mainId = $_GET['product_id'];
			$arrp = array();
			$arrpopup = array();
			$results2 = $db->query("SELECT * FROM product_detail where storeName = '$store' AND product_id ='$mainId'");
			$row2 = mysqli_fetch_assoc($results2); 
			$arrp["exclusion_id"] = json_decode($row2["exclusion_product"],true);
			echo json_encode($arrp);
			
 	